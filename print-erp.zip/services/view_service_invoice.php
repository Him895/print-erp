<?php
// ============================================================
// FILE: services/view_service_invoice.php
// ============================================================
require_once '../config/config.php';
require_login();

$page_title = 'Service Invoice';
$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) redirect('services_list.php');

$stmt = $conn->prepare("SELECT sv.*, c.client_name, c.phone, c.address 
    FROM services sv
    LEFT JOIN clients c ON sv.client_id = c.id
    WHERE sv.id = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$service = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$service) { set_flash('error', 'Service job not found.'); redirect('services_list.php'); }

include '../includes/header.php';
?>

<div class="flex items-center justify-between gap-3 mb-5">
    <div>
        <h1 class="text-2xl font-bold text-white">Service Invoice</h1>
        <p class="text-xs text-slate-400 mt-0.5">#<?= e($service['service_no']) ?></p>
    </div>
    <div class="flex gap-2">
        <button onclick="window.print()" class="px-4 py-2 rounded-lg bg-indigo-500/20 text-indigo-300 text-xs font-semibold hover:bg-indigo-500/30 transition">
            <i class="fas fa-print mr-1"></i> Print Bill
        </button>
        <a href="services_list.php" class="px-4 py-2 rounded-lg bg-white/5 border border-white/10 text-slate-300 text-xs hover:bg-white/10 transition">
            <i class="fas fa-arrow-left mr-1"></i> Back
        </a>
    </div>
</div>

<div class="glass-dark rounded-2xl p-6 max-w-3xl mx-auto print-area">
    
    <!-- Bill Header -->
    <div class="flex justify-between items-start border-b border-white/10 pb-6 mb-6">
        <div>
            <h2 class="text-2xl font-bold text-white mb-1">PrintERP</h2>
            <p class="text-xs text-slate-400">Print Service Invoice</p>
        </div>
        <div class="text-right">
            <div class="text-lg font-bold text-indigo-300 mb-1">INVOICE</div>
            <div class="text-xs text-slate-400">No: <?= e($service['service_no']) ?></div>
            <div class="text-xs text-slate-400">Date: <?= fmt_date($service['service_date']) ?></div>
        </div>
    </div>

    <!-- Client Info -->
    <div class="mb-6">
        <div class="text-[10px] uppercase tracking-wider text-slate-500 font-semibold mb-1">Billed To:</div>
        <div class="text-white font-semibold"><?= e($service['client_name'] ?? 'Walk-in') ?></div>
        <?php if($service['phone']): ?><div class="text-xs text-slate-400"><i class="fas fa-phone text-[10px] mr-1"></i><?= e($service['phone']) ?></div><?php endif; ?>
    </div>

    <!-- Service Detail -->
    <table class="w-full text-xs mb-6">
        <thead>
            <tr class="text-left border-b border-white/10 bg-white/5">
                <th class="px-3 py-2 text-slate-400 font-medium">Description</th>
                <th class="px-3 py-2 text-slate-400 font-medium text-center">Qty</th>
                <th class="px-3 py-2 text-slate-400 font-medium text-right">Rate</th>
                <th class="px-3 py-2 text-slate-400 font-medium text-right">Amount</th>
            </tr>
        </thead>
        <tbody>
            <tr class="border-b border-white/5">
                <td class="px-3 py-3">
                    <div class="text-white font-medium">Custom Printing Service</div>
                    <div class="text-[10px] text-slate-400 mt-1 whitespace-pre-wrap"><?= e($service['notes']) ?></div>
                </td>
                <td class="px-3 py-3 text-center text-slate-300"><?= $service['qty'] ?></td>
                <td class="px-3 py-3 text-right text-slate-300"><?= money($service['print_charge_per_pc']) ?></td>
                <td class="px-3 py-3 text-right text-emerald-300 font-semibold"><?= money($service['total_amount']) ?></td>
            </tr>
        </tbody>
    </table>

    <!-- Totals -->
    <div class="flex justify-end">
        <div class="w-64 space-y-2">
            <div class="flex justify-between border-t border-white/10 pt-2 text-sm font-bold text-slate-300"><span>Grand Total:</span> <span class="text-emerald-400 text-lg"><?= money($service['total_amount']) ?></span></div>
        </div>
    </div>

    <div class="mt-8 pt-4 border-t border-white/10 text-center text-[10px] text-slate-500">
        Thank you for your business! <br> Job Status: <strong class="uppercase"><?= str_replace('_', ' ', $service['status']) ?></strong>
    </div>

</div>

<style>
    @media print {
        body * { visibility: hidden; }
        .print-area, .print-area * { visibility: visible; }
        .print-area { position: absolute; left: 0; top: 0; width: 100%; background: white; color: black; }
        .print-area .text-white, .print-area .text-slate-400, .print-area .text-indigo-300, .print-area .text-emerald-400 { color: black !important; }
        .print-area .bg-white\/5 { background: #f3f4f6 !important; }
        .print-area .border-white\/10 { border-color: #e5e7eb !important; }
    }
</style>

<?php include '../includes/footer.php'; ?>