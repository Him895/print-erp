<?php
// ============================================================
// FILE: services/add_service.php
// ============================================================
require_once '../config/config.php';
require_login();

$page_title = 'Add Print Service';
$error = '';

// Fetch Clients
$clients = $conn->query("SELECT * FROM clients WHERE is_active = 1 ORDER BY client_name")->fetch_all(MYSQLI_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $client_id   = (int)($_POST['client_id'] ?? 0);
    $service_date = trim($_POST['service_date'] ?? date('Y-m-d'));
    $qty          = (int)($_POST['qty'] ?? 0);
    $rate         = (float)($_POST['rate'] ?? 0);
    $print_type   = trim($_POST['print_type'] ?? 'Logo');
    $notes        = trim($_POST['notes'] ?? '');
    $total_amount = $qty * $rate;

    if ($client_id <= 0) {
        $error = 'Client select karna zaroori hai (Walk-in ke liye client add karein).';
    } elseif ($qty <= 0 || $rate <= 0) {
        $error = 'Qty aur Rate 0 se bade hone chahiye.';
    } else {
        $service_no = generate_no($conn, 'services', 'service_no', 'SRV');
        // Default status pending rakhenge
        $status = 'pending';
        
        $stmt = $conn->prepare("INSERT INTO services 
            (service_no, client_id, sale_id, service_type, qty, print_charge_per_pc, total_amount, notes, status, service_date) 
            VALUES (?, ?, NULL, 'custom_print', ?, ?, ?, ?, ?, ?)");
        
        $full_notes = "Print Type: $print_type\n" . $notes;
        
        $stmt->bind_param('siidddss', $service_no, $client_id, $qty, $rate, $total_amount, $full_notes, $status, $service_date);
        
        if ($stmt->execute()) {
            $new_service_id = $stmt->insert_id;
            set_flash('success', "Direct Print Job ($service_no) created!");
            redirect('view_service_invoice.php?id=' . $new_service_id);
        } else {
            $error = 'Insert failed: ' . $conn->error;
        }
        $stmt->close();
    }
}

include '../includes/header.php';
?>

<style>
    select { background-color: #1e293b !important; color: #fff !important; }
    select option { background-color: #1e293b !important; color: #fff !important; }
</style>

<div class="flex items-center justify-between gap-3 mb-5">
    <div>
        <h1 class="text-2xl font-bold text-white">Add Print Service</h1>
        <p class="text-xs text-slate-400 mt-0.5">Sirf printing ka kaam (bina product sale ke)</p>
    </div>
    <a href="services_list.php" class="px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-slate-300 text-xs hover:bg-white/10 transition">
        <i class="fas fa-arrow-left mr-1"></i> Back
    </a>
</div>

<?php if ($error): ?>
    <div class="mb-4 rounded-xl p-3 text-sm bg-rose-500/15 border border-rose-500/30 text-rose-300">
        <i class="fas fa-exclamation-circle mr-2"></i><?= e($error) ?>
    </div>
<?php endif; ?>

<form method="POST" class="glass-dark rounded-2xl p-5 max-w-3xl">
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        
        <div class="md:col-span-2">
            <label class="text-xs text-slate-400 mb-1 block">Client *</label>
            <select name="client_id" required class="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-slate-200 outline-none focus:border-indigo-500/50">
                <option value="">-- Select Client --</option>
                <?php foreach ($clients as $c): ?>
                    <option value="<?= $c['id'] ?>"><?= e($c['client_name']) ?></option>
                <?php endforeach; ?>
            </select>
            <p class="text-[10px] text-slate-500 mt-1">Agar naya client hai, toh pehle <a href="../clients/add_client.php" target="_blank" class="text-indigo-400 underline">yahan click karke add karein</a>.</p>
        </div>

        <div>
            <label class="text-xs text-slate-400 mb-1 block">Service Date *</label>
            <input type="date" name="service_date" required value="<?= date('Y-m-d') ?>" class="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-slate-200 outline-none focus:border-indigo-500/50">
        </div>

        <div>
            <label class="text-xs text-slate-400 mb-1 block">Print Type</label>
            <select name="print_type" class="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-slate-200 outline-none focus:border-indigo-500/50">
                <option value="Logo">Logo</option>
                <option value="Text">Text / Name</option>
                <option value="Full Print">Full Design</option>
            </select>
        </div>

        <div>
            <label class="text-xs text-slate-400 mb-1 block">Quantity (Pieces) *</label>
            <input type="number" step="1" min="1" name="qty" required placeholder="e.g. 10" class="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-indigo-500/50">
        </div>

        <div>
            <label class="text-xs text-slate-400 mb-1 block">Print Rate (₹ per piece) *</label>
            <input type="number" step="1" min="1" name="rate" required placeholder="e.g. 50" class="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-indigo-500/50">
        </div>

        <div class="md:col-span-2">
            <label class="text-xs text-slate-400 mb-1 block">Notes / Instructions (Optional)</label>
            <input type="text" name="notes" placeholder="e.g. Front side pe logo print karna hai" class="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-slate-200 outline-none focus:border-indigo-500/50">
        </div>
    </div>

    <div class="flex items-center gap-2 mt-6 pt-4 border-t border-white/5">
        <button type="submit" class="px-6 py-2.5 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-500 text-white text-sm font-semibold hover:-translate-y-0.5 transition-all">
            <i class="fas fa-save mr-1"></i> Create Job & Invoice
        </button>
        <a href="services_list.php" class="px-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-slate-300 text-sm hover:bg-white/10 transition">Cancel</a>
    </div>
</form>

<?php include '../includes/footer.php'; ?>