<?php
// ============================================================
// FILE: services/services_list.php
// ============================================================
require_once '../config/config.php';
require_login();

$page_title = 'Services / Print Jobs';

// Fetch all services with client info
$sql = "SELECT sv.*, c.client_name, s.sale_no 
        FROM services sv
        LEFT JOIN clients c ON sv.client_id = c.id
        LEFT JOIN sales s ON sv.sale_id = s.id
        ORDER BY sv.created_at DESC";
$services = $conn->query($sql)->fetch_all(MYSQLI_ASSOC);

// Summary Stats
$totalJobs = count($services);
$pendingJobs = 0;
$inProgressJobs = 0;
$completedJobs = 0;

foreach ($services as $srv) {
    if ($srv['status'] === 'pending') $pendingJobs++;
    elseif ($srv['status'] === 'in_progress') $inProgressJobs++;
    elseif ($srv['status'] === 'completed' || $srv['status'] === 'delivered') $completedJobs++;
}

include '../includes/header.php';
?>

<div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5">
    <div>
        <h1 class="text-2xl font-bold text-white tracking-tight">Print Services</h1>
        <p class="text-xs text-slate-400 mt-0.5">Manage all printing jobs</p>
    </div>
    <a href="add_service.php" class="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-500 text-white text-sm font-semibold hover:-translate-y-0.5 hover:shadow-lg hover:shadow-indigo-500/40 transition-all">
        <i class="fas fa-plus-circle"></i> Add Print Job
    </a>
</div>

<!-- Stats -->
<div class="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
    <div class="glass-dark rounded-xl p-4 border border-white/10">
        <div class="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">Total Jobs</div>
        <div class="text-2xl font-bold bg-gradient-to-r from-blue-300 to-blue-500 bg-clip-text text-transparent mt-1"><?= $totalJobs ?></div>
    </div>
    <div class="glass-dark rounded-xl p-4 border border-white/10">
        <div class="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">Pending</div>
        <div class="text-2xl font-bold bg-gradient-to-r from-amber-300 to-amber-500 bg-clip-text text-transparent mt-1"><?= $pendingJobs ?></div>
    </div>
    <div class="glass-dark rounded-xl p-4 border border-white/10">
        <div class="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">In Progress</div>
        <div class="text-2xl font-bold bg-gradient-to-r from-indigo-300 to-indigo-500 bg-clip-text text-transparent mt-1"><?= $inProgressJobs ?></div>
    </div>
    <div class="glass-dark rounded-xl p-4 border border-white/10">
        <div class="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">Completed</div>
        <div class="text-2xl font-bold bg-gradient-to-r from-emerald-300 to-emerald-500 bg-clip-text text-transparent mt-1"><?= $completedJobs ?></div>
    </div>
</div>

<!-- Table -->
<div class="glass-dark rounded-2xl overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full text-xs">
            <thead>
                <tr class="text-left border-b border-white/10 bg-white/3">
                    <th class="px-4 py-3 text-slate-400 font-medium">#</th>
                    <th class="px-4 py-3 text-slate-400 font-medium">Service No</th>
                    <th class="px-4 py-3 text-slate-400 font-medium">Client</th>
                    <th class="px-4 py-3 text-slate-400 font-medium">Source</th>
                    <th class="px-4 py-3 text-slate-400 font-medium text-right">Amount</th>
                    <th class="px-4 py-3 text-slate-400 font-medium text-center">Status</th>
                    <th class="px-4 py-3 text-slate-400 font-medium">Date</th>
                    <th class="px-4 py-3 text-slate-400 font-medium text-center">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($services)): ?>
                    <?php foreach ($services as $i => $srv): 
                        $statusClass = 'bg-amber-500/15 text-amber-300'; // pending
                        if ($srv['status'] === 'in_progress') $statusClass = 'bg-indigo-500/15 text-indigo-300';
                        if ($srv['status'] === 'completed') $statusClass = 'bg-emerald-500/15 text-emerald-300';
                        if ($srv['status'] === 'delivered') $statusClass = 'bg-teal-500/15 text-teal-300';
                    ?>
                        <tr class="border-b border-white/5 hover:bg-white/3 transition">
                            <td class="px-4 py-3 text-slate-500"><?= $i + 1 ?></td>
                            <td class="px-4 py-3 text-indigo-300 font-medium"><?= e($srv['service_no']) ?></td>
                            <td class="px-4 py-3 text-white"><?= e($srv['client_name'] ?? 'Walk-in') ?></td>
                            <td class="px-4 py-3">
                                <?php if($srv['sale_no']): ?>
                                    <a href="../sales/view_sale.php?id=<?= $srv['sale_id'] ?>" class="text-[10px] text-indigo-400 hover:text-indigo-300 underline">
                                        <i class="fas fa-shopping-bag mr-1"></i><?= e($srv['sale_no']) ?>
                                    </a>
                                <?php else: ?>
                                    <span class="text-[10px] text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded">Direct Job</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-4 py-3 text-right text-emerald-300 font-semibold"><?= money($srv['total_amount']) ?></td>
                            <td class="px-4 py-3 text-center">
                                <span class="px-2 py-0.5 rounded-full <?= $statusClass ?> capitalize text-[10px]"><?= str_replace('_', ' ', $srv['status']) ?></span>
                            </td>
                            <td class="px-4 py-3 text-slate-400"><?= fmt_date($srv['service_date']) ?></td>
                            <td class="px-4 py-3 text-center">
                                <div class="flex items-center justify-center gap-1.5">
                                    <!-- Manage Job -->
                                    <a href="view_service.php?id=<?= $srv['id'] ?>" class="w-7 h-7 rounded-lg bg-indigo-500/15 text-indigo-300 inline-flex items-center justify-center hover:bg-indigo-500/30 transition" title="Manage & Update Status">
                                        <i class="fas fa-tasks text-[10px]"></i>
                                    </a>
                                    
                                    <!-- Print Invoice -->
                                    <a href="view_service_invoice.php?id=<?= $srv['id'] ?>" class="w-7 h-7 rounded-lg bg-emerald-500/15 text-emerald-300 inline-flex items-center justify-center hover:bg-emerald-500/30 transition" title="Print Invoice">
                                        <i class="fas fa-file-invoice text-[10px]"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8">
                            <div class="text-center py-12 text-slate-500">
                                <i class="fas fa-print text-3xl block mb-2 opacity-30"></i>
                                <div class="text-sm">No print jobs yet</div>
                                <p class="text-[10px] mt-1 text-slate-600">Click "Add Print Job" to create a direct service, or generate via Sales.</p>
                            </div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include '../includes/footer.php'; ?>