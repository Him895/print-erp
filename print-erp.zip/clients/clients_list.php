<?php
// ============================================================
// FILE: clients/clients_list.php
// ============================================================
require_once '../config/config.php';
require_login();

$page_title = 'Clients';

// Fetch all clients
$clients = $conn->query("SELECT * FROM clients WHERE is_active = 1 ORDER BY created_at DESC")->fetch_all(MYSQLI_ASSOC);
$totalClients = count($clients);

include '../includes/header.php';
?>

<div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5">
    <div>
        <h1 class="text-2xl font-bold text-white tracking-tight">Clients</h1>
        <p class="text-xs text-slate-400 mt-0.5">Manage your customers</p>
    </div>
    <a href="add_client.php" class="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-500 text-white text-sm font-semibold hover:-translate-y-0.5 hover:shadow-lg hover:shadow-indigo-500/40 transition-all">
        <i class="fas fa-plus-circle"></i> Add Client
    </a>
</div>

<!-- Summary Card -->
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
    <div class="glass-dark rounded-xl p-4">
        <div class="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">Total Clients</div>
        <div class="text-2xl font-bold bg-gradient-to-r from-blue-300 to-blue-500 bg-clip-text text-transparent mt-1"><?= $totalClients ?></div>
    </div>
</div>

<!-- Table -->
<div class="glass-dark rounded-2xl overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full text-xs">
            <thead>
                <tr class="text-left border-b border-white/10 bg-white/3">
                    <th class="px-4 py-3 text-slate-400 font-medium">#</th>
                    <th class="px-4 py-3 text-slate-400 font-medium">Client Name</th>
                    <th class="px-4 py-3 text-slate-400 font-medium">Contact</th>
                    <th class="px-4 py-3 text-slate-400 font-medium">GST No</th>
                    <th class="px-4 py-3 text-slate-400 font-medium text-center">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($clients)): ?>
                    <?php foreach ($clients as $i => $c): ?>
                        <tr class="border-b border-white/5 hover:bg-white/3 transition">
                            <td class="px-4 py-3 text-slate-500"><?= $i + 1 ?></td>
                            <td class="px-4 py-3">
                                <div class="flex items-center gap-2.5">
                                    <span class="w-9 h-9 rounded-lg flex items-center justify-center text-[13px] bg-blue-500/15 text-blue-300">
                                        <i class="fas fa-user"></i>
                                    </span>
                                    <div>
                                        <span class="text-white font-medium block"><?= e($c['client_name']) ?></span>
                                        <?php if($c['address']): ?><span class="text-[10px] text-slate-500 block truncate max-w-[150px]"><?= e($c['address']) ?></span><?php endif; ?>
                                    </div>
                                </div>
                            </td>
                            <td class="px-4 py-3 text-slate-300">
                                <?php if($c['phone']): ?><div><i class="fas fa-phone text-[10px] mr-1 text-slate-500"></i><?= e($c['phone']) ?></div><?php endif; ?>
                                <?php if($c['email']): ?><div><i class="fas fa-envelope text-[10px] mr-1 text-slate-500"></i><?= e($c['email']) ?></div><?php endif; ?>
                            </td>
                            <td class="px-4 py-3 text-slate-400"><?= e($c['gst_no'] ?: '-') ?></td>
                            <td class="px-4 py-3">
                                <div class="flex items-center justify-center gap-1.5">
                                    <a href="edit_client.php?id=<?= $c['id'] ?>" class="w-7 h-7 rounded-lg bg-indigo-500/15 text-indigo-300 flex items-center justify-center hover:bg-indigo-500/30 transition" title="Edit">
                                        <i class="fas fa-edit text-[10px]"></i>
                                    </a>
                                    <a href="delete_client.php?id=<?= $c['id'] ?>" onclick="return confirm('Delete this client?')" class="w-7 h-7 rounded-lg bg-rose-500/15 text-rose-300 flex items-center justify-center hover:bg-rose-500/30 transition" title="Delete">
                                        <i class="fas fa-trash text-[10px]"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5">
                            <div class="text-center py-12 text-slate-500">
                                <i class="fas fa-users text-3xl block mb-2 opacity-30"></i>
                                <div class="text-sm">No clients yet</div>
                                <a href="add_client.php" class="inline-block mt-2 text-indigo-400 hover:text-indigo-300 text-xs underline">Add your first client →</a>
                            </div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include '../includes/footer.php'; ?>