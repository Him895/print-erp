<?php
// ============================================================
// FILE: clients/edit_client.php
// ============================================================
require_once '../config/config.php';
require_login();

$page_title = 'Edit Client';
$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) redirect('clients_list.php');

$stmt = $conn->prepare("SELECT * FROM clients WHERE id = ? AND is_active = 1");
$stmt->bind_param('i', $id);
$stmt->execute();
$client = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$client) { set_flash('error', 'Client not found.'); redirect('clients_list.php'); }

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name    = trim($_POST['client_name'] ?? '');
    $phone   = trim($_POST['phone'] ?? '');
    $email   = trim($_POST['email'] ?? '');
    $gst     = trim($_POST['gst_no'] ?? '');
    $address = trim($_POST['address'] ?? '');

    if ($name === '') {
        $error = 'Client name required.';
    } else {
        $stmt = $conn->prepare("UPDATE clients SET client_name=?, phone=?, email=?, gst_no=?, address=? WHERE id=?");
        $stmt->bind_param('sssssi', $name, $phone, $email, $gst, $address, $id);
        if ($stmt->execute()) {
            set_flash('success', 'Client updated successfully!');
            redirect('clients_list.php');
        } else {
            $error = 'Update failed: ' . $conn->error;
        }
        $stmt->close();
    }
    $client = array_merge($client, $_POST);
}

include '../includes/header.php';
?>

<div class="flex items-center justify-between gap-3 mb-5">
    <div>
        <h1 class="text-2xl font-bold text-white">Edit Client</h1>
        <p class="text-xs text-slate-400 mt-0.5">ID #<?= $id ?></p>
    </div>
    <a href="clients_list.php" class="px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-slate-300 text-xs hover:bg-white/10 transition">
        <i class="fas fa-arrow-left mr-1"></i> Back
    </a>
</div>

<?php if ($error): ?>
    <div class="mb-4 rounded-xl p-3 text-sm bg-rose-500/15 border border-rose-500/30 text-rose-300">
        <i class="fas fa-exclamation-circle mr-2"></i><?= e($error) ?>
    </div>
<?php endif; ?>

<form method="POST" class="glass-dark rounded-2xl p-5 max-w-2xl">
    <div class="space-y-4">
        <div>
            <label class="text-xs text-slate-400 mb-1 block">Client Name *</label>
            <input type="text" name="client_name" required value="<?= e($client['client_name']) ?>" class="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-slate-200 outline-none focus:border-indigo-500/50">
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label class="text-xs text-slate-400 mb-1 block">Phone</label>
                <input type="text" name="phone" value="<?= e($client['phone'] ?? '') ?>" class="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-slate-200 outline-none focus:border-indigo-500/50">
            </div>
            <div>
                <label class="text-xs text-slate-400 mb-1 block">Email</label>
                <input type="email" name="email" value="<?= e($client['email'] ?? '') ?>" class="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-slate-200 outline-none focus:border-indigo-500/50">
            </div>
        </div>

        <div>
            <label class="text-xs text-slate-400 mb-1 block">GST No (Optional)</label>
            <input type="text" name="gst_no" value="<?= e($client['gst_no'] ?? '') ?>" class="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-slate-200 outline-none focus:border-indigo-500/50">
        </div>

        <div>
            <label class="text-xs text-slate-400 mb-1 block">Address</label>
            <textarea name="address" rows="3" class="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-slate-200 outline-none focus:border-indigo-500/50 resize-none"><?= e($client['address'] ?? '') ?></textarea>
        </div>

        <div class="flex items-center gap-2 pt-4 border-t border-white/5">
            <button type="submit" class="px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-500 text-white text-sm font-semibold hover:-translate-y-0.5 hover:shadow-lg hover:shadow-indigo-500/30 transition-all">
                <i class="fas fa-save mr-1"></i> Update Client
            </button>
            <a href="clients_list.php" class="px-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-slate-300 text-sm hover:bg-white/10 transition">Cancel</a>
        </div>
    </div>
</form>

<?php include '../includes/footer.php'; ?>