<?php
// ============================================================
// FILE: dashboard.php
// DESCRIPTION: Modern dashboard with glassmorphism & charts
// ============================================================
require_once 'config/config.php';
require_login();

$user_id   = $_SESSION['user_id'];
$full_name = $_SESSION['full_name'] ?? 'User';
$role      = $_SESSION['role'] ?? 'sales';

// ============================================================
// FETCH DASHBOARD STATISTICS
// ============================================================

// Products (Category-wise count ke liye JOIN)
$productStats = $conn->query("SELECT 
    COUNT(p.id) AS total,
    COALESCE(SUM(p.stock_qty), 0) AS total_stock,
    SUM(CASE WHEN c.category_name LIKE '%T-Shirt%' THEN 1 ELSE 0 END) AS tshirt_count,
    SUM(CASE WHEN c.category_name LIKE '%Shirt%' AND c.category_name NOT LIKE '%T-Shirt%' THEN 1 ELSE 0 END) AS shirt_count,
    SUM(CASE WHEN c.category_name LIKE '%Bottle%' THEN 1 ELSE 0 END) AS bottle_count
    FROM products p
    LEFT JOIN categories c ON p.category_id = c.id
    WHERE p.is_active = 1")->fetch_assoc();

// Sales
$salesStats = $conn->query("SELECT 
    COUNT(*) AS total_sales,
    COALESCE(SUM(grand_total), 0) AS total_revenue,
    COALESCE(SUM(print_total), 0) AS total_print_revenue,
    COALESCE(SUM(CASE WHEN DATE(sale_date) = CURDATE() THEN grand_total ELSE 0 END), 0) AS today_revenue,
    COUNT(CASE WHEN DATE(sale_date) = CURDATE() THEN 1 END) AS today_count
    FROM sales WHERE status != 'cancelled'")->fetch_assoc();

// Services (print jobs)
$serviceStats = $conn->query("SELECT 
    COUNT(*) AS total,
    SUM(CASE WHEN status = 'pending'     THEN 1 ELSE 0 END) AS pending,
    SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) AS in_progress,
    SUM(CASE WHEN status = 'completed'   THEN 1 ELSE 0 END) AS completed,
    SUM(CASE WHEN status = 'delivered'   THEN 1 ELSE 0 END) AS delivered
    FROM services")->fetch_assoc();

// Pending Prints from Sale Items (jinke print_status pending hai)
$printJobStats = $conn->query("SELECT 
    COUNT(*) AS total,
    SUM(CASE WHEN print_status = 'pending'     THEN 1 ELSE 0 END) AS pending,
    SUM(CASE WHEN print_status = 'in_progress' THEN 1 ELSE 0 END) AS in_progress,
    SUM(CASE WHEN print_status = 'completed'   THEN 1 ELSE 0 END) AS completed
    FROM sale_items WHERE print_charge_total > 0")->fetch_assoc();

// Clients
$clientCount = $conn->query("SELECT COUNT(*) AS total FROM clients WHERE is_active = 1")->fetch_assoc()['total'];

// Vendors
$vendorCount = $conn->query("SELECT COUNT(*) AS total FROM vendors WHERE is_active = 1")->fetch_assoc()['total'];

// Payments (Receivable = Aayaa, Payable = Gayaa)
$paymentStats = $conn->query("SELECT 
    COALESCE(SUM(CASE WHEN ref_type = 'sale' AND status = 'confirmed' THEN amount ELSE 0 END), 0) AS total_received,
    COALESCE(SUM(CASE WHEN ref_type = 'purchase' AND status = 'confirmed' THEN amount ELSE 0 END), 0) AS total_paid,
    COUNT(CASE WHEN status = 'confirmed' THEN 1 END) AS confirmed_count
    FROM payments")->fetch_assoc();

// ============================================================
// CHARTS DATA
// ============================================================

// Monthly Sales (last 6 months)
$salesChartData = ['labels' => [], 'values' => []];
$q = $conn->query("SELECT 
    DATE_FORMAT(sale_date, '%b') AS month,
    DATE_FORMAT(sale_date, '%m') AS mnum,
    COALESCE(SUM(grand_total), 0) AS total
    FROM sales 
    WHERE status != 'cancelled'
      AND sale_date >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
    GROUP BY DATE_FORMAT(sale_date, '%Y-%m'), DATE_FORMAT(sale_date, '%b'), DATE_FORMAT(sale_date, '%m')
    ORDER BY mnum ASC");
while ($row = $q->fetch_assoc()) {
    $salesChartData['labels'][] = $row['month'];
    $salesChartData['values'][] = (float)$row['total'];
}

// Product Stock by Category (Donut)
$productChartData = [
    'labels' => ['T-Shirts', 'Shirts', 'Bottles'],
    'values' => [
        (int)($productStats['tshirt_count'] ?? 0),
        (int)($productStats['shirt_count']  ?? 0),
        (int)($productStats['bottle_count'] ?? 0),
    ],
    'colors' => ['#818cf8', '#34d399', '#fbbf24']
];

// Service Status (Donut)
$serviceChartData = [
    'labels' => ['Pending', 'In Progress', 'Completed', 'Delivered'],
    'values' => [
        (int)($serviceStats['pending']     ?? 0),
        (int)($serviceStats['in_progress'] ?? 0),
        (int)($serviceStats['completed']   ?? 0),
        (int)($serviceStats['delivered']   ?? 0),
    ],
    'colors' => ['#fbbf24', '#818cf8', '#34d399', '#14b8a6']
];

// Payment Summary (Bar) - Ab Received vs Paid
$paymentChartData = [
    'labels' => ['Received (IN)', 'Paid (OUT)'],
    'values' => [
        (float)($paymentStats['total_received'] ?? 0),
        (float)($paymentStats['total_paid'] ?? 0),
    ],
    'colors' => ['#34d399', '#f87171']
];

// ============================================================
// RECENT ACTIVITIES
// ============================================================

// Recent Sales
$recentSales = [];
$q = $conn->query("SELECT s.id, s.sale_no, s.grand_total, s.status,
                          c.client_name, s.created_at
                   FROM sales s
                   LEFT JOIN clients c ON s.client_id = c.id
                   ORDER BY s.created_at DESC LIMIT 5");
while ($row = $q->fetch_assoc()) $recentSales[] = $row;

// Recent Services
$recentServices = [];
$q = $conn->query("SELECT sv.id, sv.service_no, sv.total_amount, sv.status,
                          c.client_name, sv.created_at
                   FROM services sv
                   LEFT JOIN clients c ON sv.client_id = c.id
                   ORDER BY sv.created_at DESC LIMIT 5");
while ($row = $q->fetch_assoc()) $recentServices[] = $row;

// Recent Payments
$recentPayments = [];
$q = $conn->query("SELECT p.id, p.payment_no, p.amount, p.payment_mode, p.ref_type,
                          c.client_name, p.created_at
                   FROM payments p
                   LEFT JOIN clients c ON p.client_id = c.id
                   ORDER BY p.created_at DESC LIMIT 5");
while ($row = $q->fetch_assoc()) $recentPayments[] = $row;

// ============================================================
// ROLE-BASED QUICK ACCESS (Invoices ki jagah Categories daala)
// ============================================================
$menuItems = [
    'admin' => [
        ['icon' => 'fa-tachometer-alt', 'label' => 'Dashboard', 'link' => 'dashboard.php', 'color' => 'indigo'],
        ['icon' => 'fa-tshirt', 'label' => 'Products', 'link' => 'products/products_list.php', 'color' => 'rose'],
        ['icon' => 'fa-tags', 'label' => 'Categories', 'link' => 'categories/categories_list.php', 'color' => 'sky'],
        ['icon' => 'fa-truck', 'label' => 'Vendors', 'link' => 'vendors/vendors_list.php', 'color' => 'purple'],
        ['icon' => 'fa-shopping-cart', 'label' => 'Purchases', 'link' => 'product_purchase/purchases_list.php', 'color' => 'orange'],
        ['icon' => 'fa-users', 'label' => 'Clients', 'link' => 'clients/clients_list.php', 'color' => 'blue'],
        ['icon' => 'fa-file-invoice-dollar', 'label' => 'Sales', 'link' => 'sales/sales_list.php', 'color' => 'emerald'],
        ['icon' => 'fa-print', 'label' => 'Services', 'link' => 'services/services_list.php', 'color' => 'amber'],
        ['icon' => 'fa-money-bill-wave', 'label' => 'Payments', 'link' => 'payments/payments_list.php', 'color' => 'teal'],
        ['icon' => 'fa-chart-bar', 'label' => 'Reports', 'link' => 'reports/sales_report.php', 'color' => 'sky'],
        ['icon' => 'fa-users-cog', 'label' => 'Users', 'link' => 'users/users_list.php', 'color' => 'red'],
    ],
    'manager' => [
        ['icon' => 'fa-tachometer-alt', 'label' => 'Dashboard', 'link' => 'dashboard.php', 'color' => 'indigo'],
        ['icon' => 'fa-tshirt', 'label' => 'Products', 'link' => 'products/products_list.php', 'color' => 'rose'],
        ['icon' => 'fa-tags', 'label' => 'Categories', 'link' => 'categories/categories_list.php', 'color' => 'sky'],
        ['icon' => 'fa-truck', 'label' => 'Vendors', 'link' => 'vendors/vendors_list.php', 'color' => 'purple'],
        ['icon' => 'fa-shopping-cart', 'label' => 'Purchases', 'link' => 'product_purchase/purchases_list.php', 'color' => 'orange'],
        ['icon' => 'fa-users', 'label' => 'Clients', 'link' => 'clients/clients_list.php', 'color' => 'blue'],
        ['icon' => 'fa-file-invoice-dollar', 'label' => 'Sales', 'link' => 'sales/sales_list.php', 'color' => 'emerald'],
        ['icon' => 'fa-print', 'label' => 'Services', 'link' => 'services/services_list.php', 'color' => 'amber'],
        ['icon' => 'fa-money-bill-wave', 'label' => 'Payments', 'link' => 'payments/payments_list.php', 'color' => 'teal'],
        ['icon' => 'fa-chart-bar', 'label' => 'Reports', 'link' => 'reports/sales_report.php', 'color' => 'sky'],
    ],
    'sales' => [
        ['icon' => 'fa-tachometer-alt', 'label' => 'Dashboard', 'link' => 'dashboard.php', 'color' => 'indigo'],
        ['icon' => 'fa-tshirt', 'label' => 'Products', 'link' => 'products/products_list.php', 'color' => 'rose'],
        ['icon' => 'fa-users', 'label' => 'Clients', 'link' => 'clients/clients_list.php', 'color' => 'blue'],
        ['icon' => 'fa-file-invoice-dollar', 'label' => 'Sales', 'link' => 'sales/sales_list.php', 'color' => 'emerald'],
        ['icon' => 'fa-print', 'label' => 'Services', 'link' => 'services/services_list.php', 'color' => 'amber'],
        ['icon' => 'fa-money-bill-wave', 'label' => 'Payments', 'link' => 'payments/payments_list.php', 'color' => 'teal'],
    ],
    'service' => [
        ['icon' => 'fa-tachometer-alt', 'label' => 'Dashboard', 'link' => 'dashboard.php', 'color' => 'indigo'],
        ['icon' => 'fa-tshirt', 'label' => 'Products', 'link' => 'products/products_list.php', 'color' => 'rose'],
        ['icon' => 'fa-print', 'label' => 'Services', 'link' => 'services/services_list.php', 'color' => 'amber'],
    ],
    'accounts' => [
        ['icon' => 'fa-tachometer-alt', 'label' => 'Dashboard', 'link' => 'dashboard.php', 'color' => 'indigo'],
        ['icon' => 'fa-users', 'label' => 'Clients', 'link' => 'clients/clients_list.php', 'color' => 'blue'],
        ['icon' => 'fa-money-bill-wave', 'label' => 'Payments', 'link' => 'payments/payments_list.php', 'color' => 'teal'],
        ['icon' => 'fa-chart-bar', 'label' => 'Reports', 'link' => 'reports/sales_report.php', 'color' => 'sky'],
    ],
];
$currentMenu = $menuItems[$role] ?? $menuItems['sales'];

// Greeting
$hour = (int)date('H');
if ($hour < 12) $greeting = 'Good Morning ☀️';
elseif ($hour < 17) $greeting = 'Good Afternoon 🌤️';
elseif ($hour < 21) $greeting = 'Good Evening 🌅';
else $greeting = 'Good Night 🌙';

$currentDate = date('l, d M Y | h:i A');

// Page title for header
$page_title = 'Dashboard';

// Include header (starts HTML + sidebar)
include 'includes/header.php';
?>

<!-- ============================================================
     PAGE CONTENT
     ============================================================ -->

<!-- Greeting -->
<div class="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
    <div class="flex items-center gap-4">
        <div class="w-12 h-12 rounded-2xl bg-gradient-to-br from-indigo-500/40 to-purple-500/40 flex items-center justify-center icon-glow backdrop-blur-sm border border-white/20 flex-shrink-0">
            <i class="fas fa-tshirt text-2xl text-indigo-200"></i>
        </div>
        <div>
            <h1 class="text-2xl md:text-3xl font-bold text-white tracking-tight glow-text">Dashboard</h1>
            <p class="text-slate-300 text-sm font-light flex items-center gap-2 flex-wrap">
                <i class="fas fa-arrow-right text-indigo-400 text-xs"></i>
                <?= $greeting ?>, <span class="font-medium text-white"><?= e($full_name) ?></span>
                <span class="text-slate-400 text-xs bg-white/5 px-2 py-0.5 rounded-full uppercase"><?= e($role) ?></span>
            </p>
        </div>
    </div>
    <div class="text-xs text-slate-400 bg-white/5 px-3 py-1.5 rounded-full border border-white/5 self-start md:self-auto">
        <i class="far fa-calendar-alt mr-1"></i> <?= $currentDate ?>
    </div>
</div>

<!-- Welcome Banner -->
<div class="bg-gradient-to-r from-indigo-500/12 to-purple-500/6 border border-indigo-500/15 rounded-2xl p-4 md:p-5 mb-6">
    <div class="flex items-center gap-4">
        <div class="w-10 h-10 rounded-full bg-indigo-500/20 flex items-center justify-center flex-shrink-0">
            <i class="fas fa-star text-indigo-400"></i>
        </div>
        <div>
            <p class="text-sm text-slate-300">
                Welcome back, <span class="font-semibold text-white"><?= e($full_name) ?></span>! 
                Here's what's happening with your printing business today.
            </p>
            <p class="text-xs text-slate-400/80 mt-0.5">
                <i class="fas fa-circle text-emerald-400/50 text-[6px] mr-1"></i>
                <span class="text-white font-medium"><?= $productStats['total_stock'] ?? 0 ?></span> items in stock ·
                <span class="text-white font-medium"><?= $salesStats['total_sales'] ?? 0 ?></span> total sales ·
                <span class="text-white font-medium"><?= $serviceStats['pending'] ?? 0 ?></span> pending print jobs
            </p>
        </div>
    </div>
</div>

<!-- ===== MAIN STAT CARDS (4) ===== -->
<div class="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">

    <!-- Products -->
    <div class="glass-card rounded-2xl p-4 hover:bg-white/8 hover:border-indigo-500/25 transition-all duration-300 group">
        <div class="flex items-center justify-between">
            <div>
                <div class="text-2xl md:text-3xl font-bold bg-gradient-to-r from-indigo-300 to-indigo-500 bg-clip-text text-transparent">
                    <?= $productStats['total'] ?? 0 ?>
                </div>
                <div class="text-[10px] uppercase tracking-wider text-slate-400 font-medium mt-1">Total Products</div>
            </div>
            <div class="w-12 h-12 rounded-xl bg-indigo-500/15 text-indigo-300 flex items-center justify-center text-lg group-hover:scale-110 group-hover:rotate-[-5deg] transition-all">
                <i class="fas fa-tshirt"></i>
            </div>
        </div>
        <div class="flex gap-2 mt-2 text-[10px] text-slate-400 flex-wrap">
            <span><span class="inline-block w-1.5 h-1.5 rounded-full mr-1" style="background:#818cf8"></span> T: <?= $productStats['tshirt_count'] ?? 0 ?></span>
            <span><span class="inline-block w-1.5 h-1.5 rounded-full mr-1" style="background:#34d399"></span> S: <?= $productStats['shirt_count'] ?? 0 ?></span>
            <span><span class="inline-block w-1.5 h-1.5 rounded-full mr-1" style="background:#fbbf24"></span> B: <?= $productStats['bottle_count'] ?? 0 ?></span>
        </div>
    </div>

    <!-- Revenue -->
    <div class="glass-card rounded-2xl p-4 hover:bg-white/8 hover:border-emerald-500/25 transition-all duration-300 group">
        <div class="flex items-center justify-between">
            <div>
                <div class="text-2xl md:text-3xl font-bold bg-gradient-to-r from-emerald-300 to-emerald-500 bg-clip-text text-transparent">
                    <?= money($salesStats['total_revenue'] ?? 0) ?>
                </div>
                <div class="text-[10px] uppercase tracking-wider text-slate-400 font-medium mt-1">Total Revenue</div>
            </div>
            <div class="w-12 h-12 rounded-xl bg-emerald-500/15 text-emerald-300 flex items-center justify-center text-lg group-hover:scale-110 group-hover:rotate-[-5deg] transition-all">
                <i class="fas fa-file-invoice-dollar"></i>
            </div>
        </div>
        <div class="text-[10px] text-slate-400 mt-2">
            <i class="fas fa-receipt mr-1"></i> <?= $salesStats['total_sales'] ?? 0 ?> sales · Print: <?= money($salesStats['total_print_revenue'] ?? 0) ?>
        </div>
    </div>

    <!-- Clients -->
    <div class="glass-card rounded-2xl p-4 hover:bg-white/8 hover:border-blue-500/25 transition-all duration-300 group">
        <div class="flex items-center justify-between">
            <div>
                <div class="text-2xl md:text-3xl font-bold bg-gradient-to-r from-blue-300 to-blue-500 bg-clip-text text-transparent">
                    <?= $clientCount ?>
                </div>
                <div class="text-[10px] uppercase tracking-wider text-slate-400 font-medium mt-1">Total Clients</div>
            </div>
            <div class="w-12 h-12 rounded-xl bg-blue-500/15 text-blue-300 flex items-center justify-center text-lg group-hover:scale-110 group-hover:rotate-[-5deg] transition-all">
                <i class="fas fa-users"></i>
            </div>
        </div>
        <div class="flex gap-2 mt-2 text-[10px] text-slate-400 flex-wrap">
            <span><i class="fas fa-truck mr-1"></i> <?= $vendorCount ?> Vendors</span>
        </div>
    </div>

    <!-- Payments -->
    <div class="glass-card rounded-2xl p-4 hover:bg-white/8 hover:border-amber-500/25 transition-all duration-300 group">
        <div class="flex items-center justify-between">
            <div>
                <div class="text-2xl md:text-3xl font-bold bg-gradient-to-r from-amber-300 to-amber-500 bg-clip-text text-transparent">
                    <?= money($paymentStats['total_received'] ?? 0) ?>
                </div>
                <div class="text-[10px] uppercase tracking-wider text-slate-400 font-medium mt-1">Total Received</div>
            </div>
            <div class="w-12 h-12 rounded-xl bg-amber-500/15 text-amber-300 flex items-center justify-center text-lg group-hover:scale-110 group-hover:rotate-[-5deg] transition-all">
                <i class="fas fa-money-bill-wave"></i>
            </div>
        </div>
        <div class="flex gap-2 mt-2 text-[10px]">
            <span class="text-emerald-400">+<?= money($paymentStats['total_received'] ?? 0) ?></span>
            <span class="text-rose-400">-<?= money($paymentStats['total_paid'] ?? 0) ?></span>
        </div>
    </div>
</div>

<!-- ===== MINI STATS (4) ===== -->
<div class="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
    <div class="glass-card rounded-xl p-3 text-center">
        <div class="text-[10px] text-slate-400 uppercase tracking-wide">Vendors</div>
        <div class="text-xl font-bold text-white mt-0.5"><?= $vendorCount ?></div>
    </div>
    <div class="glass-card rounded-xl p-3 text-center">
        <div class="text-[10px] text-slate-400 uppercase tracking-wide">Pending Prints</div>
        <div class="text-xl font-bold text-amber-300 mt-0.5"><?= $serviceStats['pending'] ?? 0 ?></div>
    </div>
    <div class="glass-card rounded-xl p-3 text-center">
        <div class="text-[10px] text-slate-400 uppercase tracking-wide">Today's Sales</div>
        <div class="text-xl font-bold text-emerald-300 mt-0.5"><?= $salesStats['today_count'] ?? 0 ?></div>
    </div>
    <div class="glass-card rounded-xl p-3 text-center">
        <div class="text-[10px] text-slate-400 uppercase tracking-wide">Total Services</div>
        <div class="text-xl font-bold text-indigo-300 mt-0.5"><?= $serviceStats['total'] ?? 0 ?></div>
    </div>
</div>

<!-- ===== CHARTS ===== -->
<div class="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6">

    <div class="glass-dark rounded-2xl p-4">
        <div class="flex items-center justify-between mb-3">
            <h3 class="text-sm font-medium text-slate-300 flex items-center gap-2">
                <i class="fas fa-chart-line text-emerald-400"></i> Monthly Sales
            </h3>
            <span class="text-[10px] text-slate-400 bg-white/5 px-2 py-1 rounded-full">Last 6 months</span>
        </div>
        <div style="position: relative; height: 220px;"><canvas id="salesChart"></canvas></div>
    </div>

    <div class="glass-dark rounded-2xl p-4">
        <div class="flex items-center justify-between mb-3">
            <h3 class="text-sm font-medium text-slate-300 flex items-center gap-2">
                <i class="fas fa-tshirt text-indigo-400"></i> Product Stock
            </h3>
            <span class="text-[10px] text-slate-400 bg-white/5 px-2 py-1 rounded-full">By category</span>
        </div>
        <div style="position: relative; height: 220px;"><canvas id="productChart"></canvas></div>
    </div>

    <div class="glass-dark rounded-2xl p-4">
        <div class="flex items-center justify-between mb-3">
            <h3 class="text-sm font-medium text-slate-300 flex items-center gap-2">
                <i class="fas fa-print text-amber-400"></i> Service Status
            </h3>
            <span class="text-[10px] text-slate-400 bg-white/5 px-2 py-1 rounded-full">Print jobs</span>
        </div>
        <div style="position: relative; height: 200px;"><canvas id="serviceChart"></canvas></div>
    </div>

    <div class="glass-dark rounded-2xl p-4">
        <div class="flex items-center justify-between mb-3">
            <h3 class="text-sm font-medium text-slate-300 flex items-center gap-2">
                <i class="fas fa-money-bill-wave text-teal-400"></i> Payment Summary
            </h3>
            <span class="text-[10px] text-slate-400 bg-white/5 px-2 py-1 rounded-full">Total</span>
        </div>
        <div style="position: relative; height: 200px;"><canvas id="paymentChart"></canvas></div>
    </div>
</div>

<!-- ===== QUICK ACCESS ===== -->
<div class="mb-6">
    <h2 class="text-xs font-medium text-slate-400 tracking-wider uppercase mb-3 flex items-center gap-2">
        <i class="fas fa-rocket text-indigo-400"></i> Quick Access
    </h2>
    <div class="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-3">
        <?php foreach ($currentMenu as $item): ?>
            <a href="<?= BASE_URL . $item['link'] ?>" class="group bg-white/3 border border-white/6 rounded-xl p-3 text-center hover:bg-white/8 hover:border-indigo-500/25 hover:-translate-y-1 transition-all duration-300 relative overflow-hidden">
                <div class="w-12 h-12 mx-auto rounded-xl flex items-center justify-center mb-2 text-lg color-<?= $item['color'] ?> group-hover:scale-110 transition-transform">
                    <i class="fas <?= $item['icon'] ?>"></i>
                </div>
                <div class="text-[11px] font-medium text-slate-200"><?= e($item['label']) ?></div>
            </a>
        <?php endforeach; ?>
    </div>
</div>

<!-- ===== RECENT ACTIVITY ===== -->
<div class="grid grid-cols-1 lg:grid-cols-3 gap-4">

    <!-- Recent Sales -->
    <div class="glass-dark rounded-2xl p-4">
        <div class="flex items-center justify-between mb-3">
            <h3 class="text-sm font-medium text-slate-300 flex items-center gap-2">
                <i class="fas fa-file-invoice-dollar text-emerald-400"></i> Recent Sales
            </h3>
            <a href="<?= BASE_URL ?>sales/sales_list.php" class="text-[10px] text-indigo-400 hover:text-indigo-300 flex items-center gap-1">
                View all <i class="fas fa-arrow-right text-[8px]"></i>
            </a>
        </div>
        <?php if (!empty($recentSales)): ?>
            <?php foreach ($recentSales as $s): ?>
                <div class="py-2 border-b border-white/4 last:border-0 hover:bg-white/3 hover:pl-2 rounded transition-all">
                    <div class="flex items-center justify-between gap-2">
                        <div class="min-w-0">
                            <div class="text-xs text-white truncate"><?= e($s['sale_no']) ?></div>
                            <div class="text-[10px] text-slate-400 truncate"><?= e($s['client_name'] ?? '-') ?></div>
                        </div>
                        <div class="text-right flex-shrink-0">
                            <div class="text-xs text-emerald-400"><?= money($s['grand_total']) ?></div>
                            <span class="text-[9px] px-1.5 py-0.5 rounded-full <?= $s['status'] === 'completed' ? 'bg-emerald-500/20 text-emerald-300' : ($s['status'] === 'cancelled' ? 'bg-rose-500/20 text-rose-300' : 'bg-amber-500/20 text-amber-300') ?>"><?= ucfirst($s['status']) ?></span>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="text-center text-slate-500 py-6 text-xs"><i class="fas fa-file-invoice-dollar text-2xl block mb-2 opacity-30"></i>No sales yet</div>
        <?php endif; ?>
    </div>

    <!-- Recent Services -->
    <div class="glass-dark rounded-2xl p-4">
        <div class="flex items-center justify-between mb-3">
            <h3 class="text-sm font-medium text-slate-300 flex items-center gap-2">
                <i class="fas fa-print text-amber-400"></i> Recent Print Jobs
            </h3>
            <a href="<?= BASE_URL ?>services/services_list.php" class="text-[10px] text-indigo-400 hover:text-indigo-300 flex items-center gap-1">
                View all <i class="fas fa-arrow-right text-[8px]"></i>
            </a>
        </div>
        <?php if (!empty($recentServices)): ?>
            <?php foreach ($recentServices as $sv): ?>
                <div class="py-2 border-b border-white/4 last:border-0 hover:bg-white/3 hover:pl-2 rounded transition-all">
                    <div class="flex items-center justify-between gap-2">
                        <div class="min-w-0">
                            <div class="text-xs text-white truncate"><?= e($sv['service_no']) ?></div>
                            <div class="text-[10px] text-slate-400 truncate"><?= e($sv['client_name'] ?? '-') ?></div>
                        </div>
                        <div class="text-right flex-shrink-0">
                            <div class="text-xs text-amber-400"><?= money($sv['total_amount']) ?></div>
                            <span class="text-[9px] px-1.5 py-0.5 rounded-full <?= $sv['status'] === 'completed' || $sv['status'] === 'delivered' ? 'bg-emerald-500/20 text-emerald-300' : ($sv['status'] === 'in_progress' ? 'bg-indigo-500/20 text-indigo-300' : 'bg-amber-500/20 text-amber-300') ?>"><?= ucfirst(str_replace('_', ' ', $sv['status'])) ?></span>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="text-center text-slate-500 py-6 text-xs"><i class="fas fa-print text-2xl block mb-2 opacity-30"></i>No print jobs yet</div>
        <?php endif; ?>
    </div>

    <!-- Recent Payments -->
    <div class="glass-dark rounded-2xl p-4">
        <div class="flex items-center justify-between mb-3">
            <h3 class="text-sm font-medium text-slate-300 flex items-center gap-2">
                <i class="fas fa-money-bill-wave text-teal-400"></i> Recent Payments
            </h3>
            <a href="<?= BASE_URL ?>payments/payments_list.php" class="text-[10px] text-indigo-400 hover:text-indigo-300 flex items-center gap-1">
                View all <i class="fas fa-arrow-right text-[8px]"></i>
            </a>
        </div>
        <?php if (!empty($recentPayments)): ?>
            <?php foreach ($recentPayments as $p): ?>
                <div class="py-2 border-b border-white/4 last:border-0 hover:bg-white/3 hover:pl-2 rounded transition-all">
                    <div class="flex items-center justify-between gap-2">
                        <div class="min-w-0">
                            <div class="text-xs text-white truncate"><?= e($p['payment_no']) ?></div>
                            <div class="text-[10px] text-slate-400 truncate"><?= e($p['client_name'] ?? 'Vendor') ?> · <?= ucfirst($p['payment_mode']) ?></div>
                        </div>
                        <div class="text-right flex-shrink-0">
                            <div class="text-xs text-teal-400"><?= money($p['amount']) ?></div>
                            <span class="text-[9px] px-1.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300"><?= ucfirst($p['ref_type']) ?></span>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="text-center text-slate-500 py-6 text-xs"><i class="fas fa-money-bill-wave text-2xl block mb-2 opacity-30"></i>No payments yet</div>
        <?php endif; ?>
    </div>
</div>

<!-- ============================================================
     CHARTS SCRIPT
     ============================================================ -->
<script>
document.addEventListener('DOMContentLoaded', function () {

    // Common chart defaults
    Chart.defaults.color = '#94a3b8';
    Chart.defaults.font.family = 'Inter, sans-serif';
    Chart.defaults.font.size = 10;

    // ---- Monthly Sales (Line) ----
    new Chart(document.getElementById('salesChart'), {
        type: 'line',
        data: {
            labels: <?= json_encode($salesChartData['labels']) ?>,
            datasets: [{
                label: 'Revenue',
                data: <?= json_encode($salesChartData['values']) ?>,
                backgroundColor: 'rgba(99,102,241,0.1)',
                borderColor: '#818cf8',
                borderWidth: 2,
                pointBackgroundColor: '#818cf8',
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 4,
                pointHoverRadius: 6,
                tension: 0.3,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                y: { beginAtZero: true, grid: { color: 'rgba(255,255,255,0.05)' },
                     ticks: { callback: v => '₹' + v.toLocaleString() } },
                x: { grid: { display: false } }
            }
        }
    });

    // ---- Product Stock (Doughnut) ----
    new Chart(document.getElementById('productChart'), {
        type: 'doughnut',
        data: {
            labels: <?= json_encode($productChartData['labels']) ?>,
            datasets: [{
                data: <?= json_encode($productChartData['values']) ?>,
                backgroundColor: <?= json_encode($productChartData['colors']) ?>,
                borderWidth: 2,
                borderColor: 'rgba(15,23,42,0.8)'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'bottom', labels: { padding: 10, usePointStyle: true, pointStyle: 'circle' } }
            },
            cutout: '60%'
        }
    });

    // ---- Service Status (Doughnut) ----
    new Chart(document.getElementById('serviceChart'), {
        type: 'doughnut',
        data: {
            labels: <?= json_encode($serviceChartData['labels']) ?>,
            datasets: [{
                data: <?= json_encode($serviceChartData['values']) ?>,
                backgroundColor: <?= json_encode($serviceChartData['colors']) ?>,
                borderWidth: 2,
                borderColor: 'rgba(15,23,42,0.8)'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'bottom', labels: { padding: 10, usePointStyle: true, pointStyle: 'circle' } }
            },
            cutout: '60%'
        }
    });

    // ---- Payment Summary (Bar) ----
    new Chart(document.getElementById('paymentChart'), {
        type: 'bar',
        data: {
            labels: <?= json_encode($paymentChartData['labels']) ?>,
            datasets: [{
                label: 'Amount',
                data: <?= json_encode($paymentChartData['values']) ?>,
                backgroundColor: <?= json_encode($paymentChartData['colors']) ?>,
                borderColor: ['#34d399', '#f87171'],
                borderWidth: 2,
                borderRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                y: { beginAtZero: true, grid: { color: 'rgba(255,255,255,0.05)' },
                     ticks: { callback: v => '₹' + v.toLocaleString() } },
                x: { grid: { display: false } }
            }
        }
    });
});
</script>

<?php include 'includes/footer.php'; ?>