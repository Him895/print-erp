<?php
require_once '../config/config.php';
require_login();
$page_title = 'Purchase Report';

$from_date = $_GET['from'] ?? date('Y-m-01');
$to_date   = $_GET['to'] ?? date('Y-m-d');

$sql = "SELECT p.*, v.vendor_name FROM product_purchase p 
        JOIN vendors v ON p.vendor_id = v.id 
        WHERE p.purchase_date BETWEEN ? AND ? ORDER BY p.purchase_date DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param('ss', $from_date, $to_date);
$stmt->execute();
$purchases = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$totalAmount = 0; $totalPaid = 0; $totalDue = 0;
foreach ($purchases as $p) {
    $totalAmount += $p['grand_total'];
    $totalPaid += $p['paid_amount'];
    $totalDue += $p['due_amount'];
}

include '../includes/header.php';
?>

<style>
    @media print {
        body * { visibility: hidden; }
        .print-area, .print-area * { visibility: visible; }
        .print-area { position: absolute; left: 0; top: 0; width: 100%; background: white; color: black; padding: 20px; }
        .print-area .text-white { color: black !important; }
        .print-area .text-slate-400 { color: #555 !important; }
        .print-area .text-emerald-300 { color: #047857 !important; }
        .print-area .text-rose-300 { color: #b91c1c !important; }
        .print-area .bg-white\/5 { background: #f3f4f6 !important; }
        .print-area .border-white\/10 { border-color: #e5e7eb !important; }
        .print-area .glass-dark { background: white !important; border: 1px solid #ccc !important; }
        .no-print { display: none !important; }
    }
</style>

<div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5 no-print">
    <div><h1 class="text-2xl font-bold text-white">Purchase Report</h1><p class="text-xs text-slate-400 mt-0.5">Vendor-wise purchase analysis</p></div>
    <div class="flex gap-2">
        <button onclick="window.print()" class="px-4 py-2 rounded-lg bg-indigo-500/20 border border-indigo-500/30 text-indigo-300 text-xs font-semibold"><i class="fas fa-print mr-1"></i> Print</button>
        <button onclick="exportCSV()" class="px-4 py-2 rounded-lg bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-xs font-semibold"><i class="fas fa-file-excel mr-1"></i> Excel</button>
    </div>
</div>

<form method="GET" class="glass-dark rounded-2xl p-4 mb-5 flex flex-wrap gap-3 no-print">
    <div><label class="text-[10px] text-slate-400 block mb-1">From</label><input type="date" name="from" value="<?= e($from_date) ?>" class="bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-slate-200"></div>
    <div><label class="text-[10px] text-slate-400 block mb-1">To</label><input type="date" name="to" value="<?= e($to_date) ?>" class="bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-slate-200"></div>
    <button type="submit" class="px-4 py-2 rounded-lg bg-indigo-500 text-white text-xs font-semibold mt-4">Apply</button>
</form>

<div class="print-area">
    <div class="hidden print:block mb-6 text-center">
        <h2 class="text-2xl font-bold">PrintERP</h2>
        <p class="text-sm">Purchase Report (<?= fmt_date($from_date) ?> to <?= fmt_date($to_date) ?>)</p><hr class="my-3">
    </div>

    <div class="grid grid-cols-3 gap-3 mb-5">
        <div class="glass-dark rounded-xl p-4 border border-white/10"><div class="text-[10px] text-slate-400 uppercase">Total Purchase</div><div class="text-xl font-bold text-white mt-1"><?= money($totalAmount) ?></div></div>
        <div class="glass-dark rounded-xl p-4 border border-white/10"><div class="text-[10px] text-slate-400 uppercase">Paid</div><div class="text-xl font-bold text-emerald-300 mt-1"><?= money($totalPaid) ?></div></div>
        <div class="glass-dark rounded-xl p-4 border border-white/10"><div class="text-[10px] text-slate-400 uppercase">Due</div><div class="text-xl font-bold text-rose-300 mt-1"><?= money($totalDue) ?></div></div>
    </div>

    <div class="glass-dark rounded-2xl overflow-hidden">
        <table class="w-full text-xs" id="reportTable">
            <thead><tr class="text-left border-b border-white/10 bg-white/5">
                <th class="px-4 py-3 text-slate-400">Date</th><th class="px-4 py-3 text-slate-400">Purchase No</th><th class="px-4 py-3 text-slate-400">Vendor</th>
                <th class="px-4 py-3 text-slate-400 text-right">Total</th><th class="px-4 py-3 text-slate-400 text-right">Paid</th><th class="px-4 py-3 text-slate-400 text-right">Due</th>
            </tr></thead>
            <tbody>
                <?php foreach ($purchases as $p): ?>
                <tr class="border-b border-white/5">
                    <td class="px-4 py-2 text-slate-300"><?= fmt_date($p['purchase_date']) ?></td>
                    <td class="px-4 py-2 text-indigo-300"><?= e($p['purchase_no']) ?></td>
                    <td class="px-4 py-2 text-white"><?= e($p['vendor_name']) ?></td>
                    <td class="px-4 py-2 text-right text-white"><?= money($p['grand_total']) ?></td>
                    <td class="px-4 py-2 text-right text-emerald-300"><?= money($p['paid_amount']) ?></td>
                    <td class="px-4 py-2 text-right text-rose-300"><?= money($p['due_amount']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
function exportCSV() {
    let csv = ["Date,Purchase No,Vendor,Total,Paid,Due"];
    document.querySelectorAll('#reportTable tbody tr').forEach(row => {
        let cols = row.querySelectorAll('td');
        if (cols.length === 6) csv.push(Array.from(cols).map(c => '"' + c.innerText.replace(/₹|,/g, '').trim() + '"').join(","));
    });
    const blob = new Blob([csv.join("\n")], { type: "text/csv" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "purchase_report.csv"; a.click();
}
</script>
<?php include '../includes/footer.php'; ?>