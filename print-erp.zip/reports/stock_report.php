<?php
// ============================================================
// FILE: reports/stock_report.php
// ============================================================
require_once '../config/config.php';
require_login();

$page_title = 'Stock Report';

// Fetch Products with Category & Stock Value
$sql = "SELECT p.*, c.category_name 
        FROM products p 
        LEFT JOIN categories c ON p.category_id = c.id 
        WHERE p.is_active = 1 
        ORDER BY p.stock_qty ASC";
$products = $conn->query($sql)->fetch_all(MYSQLI_ASSOC);

// Summary
$totalItems = 0;
$totalPurchaseValue = 0;
$totalSaleValue = 0;

foreach ($products as $p) {
    $totalItems += $p['stock_qty'];
    $totalPurchaseValue += ($p['stock_qty'] * $p['purchase_price']);
    $totalSaleValue += ($p['stock_qty'] * $p['sale_price']);
}

include '../includes/header.php';
?>

<style>
    @media print {
        body * { visibility: hidden; }
        .print-area, .print-area * { visibility: visible; }
        .print-area { position: absolute; left: 0; top: 0; width: 100%; background: white; color: black; padding: 20px; }
        .print-area .text-white { color: black !important; }
        .print-area .text-slate-400 { color: #555 !important; }
        .print-area .text-emerald-300 { color: #047857 !important; }
        .print-area .text-amber-300 { color: #b45309 !important; }
        .print-area .bg-white\/5 { background: #f3f4f6 !important; }
        .print-area .border-white\/10 { border-color: #e5e7eb !important; }
        .print-area .glass-dark { background: white !important; border: 1px solid #ccc !important; }
        .no-print { display: none !important; }
    }
</style>

<div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5 no-print">
    <div>
        <h1 class="text-2xl font-bold text-white tracking-tight">Stock Report</h1>
        <p class="text-xs text-slate-400 mt-0.5">Current inventory status & valuation</p>
    </div>
    <div class="flex gap-2">
        <button onclick="window.print()" class="px-4 py-2 rounded-lg bg-indigo-500/20 border border-indigo-500/30 text-indigo-300 text-xs font-semibold hover:bg-indigo-500/30 transition">
            <i class="fas fa-print mr-1"></i> Print / PDF
        </button>
        <button onclick="exportCSV()" class="px-4 py-2 rounded-lg bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-xs font-semibold hover:bg-emerald-500/30 transition">
            <i class="fas fa-file-excel mr-1"></i> Export Excel
        </button>
    </div>
</div>

<!-- Printable Area -->
<div class="print-area">
    
    <div class="hidden print:block mb-6 text-center">
        <h2 class="text-2xl font-bold">PrintERP</h2>
        <p class="text-sm">Stock Report as on <?= date('d M Y') ?></p>
        <hr class="my-3">
    </div>

    <!-- Summary Cards -->
    <div class="grid grid-cols-3 gap-3 mb-5">
        <div class="glass-dark rounded-xl p-4 border border-white/10">
            <div class="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">Total Items</div>
            <div class="text-2xl font-bold text-white mt-1"><?= $totalItems ?> pcs</div>
        </div>
        <div class="glass-dark rounded-xl p-4 border border-white/10">
            <div class="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">Stock Value (Cost)</div>
            <div class="text-2xl font-bold text-rose-300 mt-1"><?= money($totalPurchaseValue) ?></div>
        </div>
        <div class="glass-dark rounded-xl p-4 border border-white/10">
            <div class="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">Est. Sale Value</div>
            <div class="text-2xl font-bold text-emerald-300 mt-1"><?= money($totalSaleValue) ?></div>
        </div>
    </div>

    <!-- Data Table -->
    <div class="glass-dark rounded-2xl overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-xs" id="reportTable">
                <thead>
                    <tr class="text-left border-b border-white/10 bg-white/5">
                        <th class="px-4 py-3 text-slate-400 font-medium">Product Name</th>
                        <th class="px-4 py-3 text-slate-400 font-medium">Category</th>
                        <th class="px-4 py-3 text-slate-400 font-medium">Color</th>
                        <th class="px-4 py-3 text-slate-400 font-medium text-center">Stock</th>
                        <th class="px-4 py-3 text-slate-400 font-medium text-right">Purchase Rate</th>
                        <th class="px-4 py-3 text-slate-400 font-medium text-right">Cost Value</th>
                        <th class="px-4 py-3 text-slate-400 font-medium text-right">Sale Rate</th>
                        <th class="px-4 py-3 text-slate-400 font-medium text-right">Sale Value</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($products as $p): 
                        $costVal = $p['stock_qty'] * $p['purchase_price'];
                        $saleVal = $p['stock_qty'] * $p['sale_price'];
                        $stockClass = $p['stock_qty'] == 0 ? 'text-rose-400 font-bold' : ($p['stock_qty'] <= 10 ? 'text-amber-400 font-bold' : 'text-emerald-400');
                    ?>
                        <tr class="border-b border-white/5">
                            <td class="px-4 py-2 text-white font-medium"><?= e($p['product_name']) ?></td>
                            <td class="px-4 py-2 text-slate-300"><?= e($p['category_name'] ?? '-') ?></td>
                            <td class="px-4 py-2 text-slate-400"><?= e($p['color'] ?? '-') ?></td>
                            <td class="px-4 py-2 text-center <?= $stockClass ?>"><?= $p['stock_qty'] ?></td>
                            <td class="px-4 py-2 text-right text-slate-300"><?= money($p['purchase_price']) ?></td>
                            <td class="px-4 py-2 text-right text-slate-400"><?= money($costVal) ?></td>
                            <td class="px-4 py-2 text-right text-slate-300"><?= money($p['sale_price']) ?></td>
                            <td class="px-4 py-2 text-right text-emerald-300"><?= money($saleVal) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
function exportCSV() {
    let csv = [];
    csv.push("Product,Category,Color,Stock,Purchase Rate,Cost Value,Sale Rate,Sale Value");
    
    const rows = document.querySelectorAll('#reportTable tbody tr');
    rows.forEach(row => {
        const cols = row.querySelectorAll('td');
        if (cols.length === 8) {
            let rowData = [];
            cols.forEach(col => {
                let text = col.innerText.replace(/₹/g, '').replace(/,/g, '').trim();
                rowData.push('"' + text + '"');
            });
            csv.push(rowData.join(","));
        }
    });

    const csvFile = new Blob([csv.join("\n")], { type: "text/csv" });
    const downloadLink = document.createElement("a");
    downloadLink.download = "stock_report_<?= date('Y-m-d') ?>.csv";
    downloadLink.href = window.URL.createObjectURL(csvFile);
    document.body.appendChild(downloadLink);
    downloadLink.click();
}
</script>

<?php include '../includes/footer.php'; ?>