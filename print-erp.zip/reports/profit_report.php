<?php
require_once '../config/config.php';
require_login();
$page_title = 'Profit Report';

$from_date = $_GET['from'] ?? date('Y-m-01');
$to_date   = $_GET['to'] ?? date('Y-m-d');

// Sales Revenue
$salesStmt = $conn->prepare("SELECT COALESCE(SUM(grand_total),0) as revenue FROM sales WHERE sale_date BETWEEN ? AND ? AND status != 'cancelled'");
$salesStmt->bind_param('ss', $from_date, $to_date); $salesStmt->execute();
$revenue = $salesStmt->get_result()->fetch_assoc()['revenue']; $salesStmt->close();

// Cost of Goods Sold (Purchase)
$purchaseStmt = $conn->prepare("SELECT COALESCE(SUM(grand_total),0) as cost FROM product_purchase WHERE purchase_date BETWEEN ? AND ?");
$purchaseStmt->bind_param('ss', $from_date, $to_date); $purchaseStmt->execute();
$cost = $purchaseStmt->get_result()->fetch_assoc()['cost']; $purchaseStmt->close();

// Service Revenue (Printing)
$serviceStmt = $conn->prepare("SELECT COALESCE(SUM(total_amount),0) as srv_revenue FROM services WHERE service_date BETWEEN ? AND ?");
$serviceStmt->bind_param('ss', $from_date, $to_date); $serviceStmt->execute();
$srvRevenue = $serviceStmt->get_result()->fetch_assoc()['srv_revenue']; $serviceStmt->close();

$totalRevenue = $revenue + $srvRevenue;
$netProfit = $totalRevenue - $cost;

// Monthly Breakdown
$monthlySql = "SELECT DATE_FORMAT(sale_date, '%b %Y') as month, SUM(grand_total) as total FROM sales WHERE sale_date BETWEEN ? AND ? GROUP BY DATE_FORMAT(sale_date, '%Y-%m'), DATE_FORMAT(sale_date, '%b %Y') ORDER BY DATE_FORMAT(sale_date, '%Y-%m')";
$mStmt = $conn->prepare($monthlySql);
$mStmt->bind_param('ss', $from_date, $to_date); $mStmt->execute();
$monthly = $mStmt->get_result()->fetch_all(MYSQLI_ASSOC); $mStmt->close();

include '../includes/header.php';
?>

<style>
    @media print {
        body * { visibility: hidden; }
        .print-area, .print-area * { visibility: visible; }
        .print-area { position: absolute; left: 0; top: 0; width: 100%; background: white; color: black; padding: 20px; }
        .print-area .text-white { color: black !important; }
        .print-area .text-slate-400 { color: #555 !important; }
        .print-area .text-emerald-300 { color: #047857 !important; }
        .print-area .text-rose-300 { color: #b91c1c !important; }
        .print-area .bg-white\/5 { background: #f3f4f6 !important; }
        .print-area .border-white\/10 { border-color: #e5e7eb !important; }
        .print-area .glass-dark { background: white !important; border: 1px solid #ccc !important; }
        .no-print { display: none !important; }
    }
</style>

<div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5 no-print">
    <div><h1 class="text-2xl font-bold text-white">Profit & Loss Report</h1></div>
    <div class="flex gap-2">
        <button onclick="window.print()" class="px-4 py-2 rounded-lg bg-indigo-500/20 border border-indigo-500/30 text-indigo-300 text-xs font-semibold"><i class="fas fa-print mr-1"></i> Print</button>
        <button onclick="exportCSV()" class="px-4 py-2 rounded-lg bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-xs font-semibold"><i class="fas fa-file-excel mr-1"></i> Excel</button>
    </div>
</div>

<form method="GET" class="glass-dark rounded-2xl p-4 mb-5 flex flex-wrap gap-3 no-print">
    <div><label class="text-[10px] text-slate-400 block mb-1">From</label><input type="date" name="from" value="<?= e($from_date) ?>" class="bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-slate-200"></div>
    <div><label class="text-[10px] text-slate-400 block mb-1">To</label><input type="date" name="to" value="<?= e($to_date) ?>" class="bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-slate-200"></div>
    <button type="submit" class="px-4 py-2 rounded-lg bg-indigo-500 text-white text-xs font-semibold mt-4">Apply</button>
</form>

<div class="print-area">
    <div class="hidden print:block mb-6 text-center">
        <h2 class="text-2xl font-bold">PrintERP</h2><p class="text-sm">Profit & Loss (<?= fmt_date($from_date) ?> to <?= fmt_date($to_date) ?>)</p><hr class="my-3">
    </div>

    <div class="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
        <div class="glass-dark rounded-xl p-4 border border-white/10"><div class="text-[10px] text-slate-400 uppercase">Total Revenue</div><div class="text-xl font-bold text-emerald-300 mt-1"><?= money($totalRevenue) ?></div></div>
        <div class="glass-dark rounded-xl p-4 border border-white/10"><div class="text-[10px] text-slate-400 uppercase">Total Cost</div><div class="text-xl font-bold text-rose-300 mt-1"><?= money($cost) ?></div></div>
        <div class="glass-dark rounded-xl p-4 border border-white/10"><div class="text-[10px] text-slate-400 uppercase">Net Profit</div><div class="text-xl font-bold <?= $netProfit >= 0 ? 'text-indigo-300' : 'text-rose-400' ?> mt-1"><?= money($netProfit) ?></div></div>
        <div class="glass-dark rounded-xl p-4 border border-white/10"><div class="text-[10px] text-slate-400 uppercase">Profit Margin</div><div class="text-xl font-bold text-amber-300 mt-1"><?= $totalRevenue > 0 ? round(($netProfit / $totalRevenue) * 100, 1) : 0 ?>%</div></div>
    </div>

    <div class="glass-dark rounded-2xl overflow-hidden">
        <div class="p-4 border-b border-white/10"><h3 class="text-sm font-semibold text-white">Monthly Sales Breakdown</h3></div>
        <table class="w-full text-xs" id="reportTable">
            <thead><tr class="text-left border-b border-white/10 bg-white/5"><th class="px-4 py-3 text-slate-400">Month</th><th class="px-4 py-3 text-slate-400 text-right">Revenue</th></tr></thead>
            <tbody>
                <?php foreach ($monthly as $m): ?>
                <tr class="border-b border-white/5"><td class="px-4 py-2 text-white"><?= e($m['month']) ?></td><td class="px-4 py-2 text-right text-emerald-300"><?= money($m['total']) ?></td></tr>
                <?php endforeach; ?>
                <?php if(empty($monthly)): ?><tr><td colspan="2" class="px-4 py-8 text-center text-slate-500">No data found</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
function exportCSV() {
    let csv = ["Month,Revenue"];
    document.querySelectorAll('#reportTable tbody tr').forEach(row => {
        let cols = row.querySelectorAll('td');
        if (cols.length === 2) csv.push(Array.from(cols).map(c => '"' + c.innerText.replace(/₹|,/g, '').trim() + '"').join(","));
    });
    const blob = new Blob([csv.join("\n")], { type: "text/csv" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "profit_report.csv"; a.click();
}
</script>
<?php include '../includes/footer.php'; ?>