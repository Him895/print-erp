<?php
require_once '../config/config.php';
require_login();
$page_title = 'Client Report';

$sql = "SELECT c.*, 
        (SELECT COALESCE(SUM(due_amount),0) FROM sales WHERE client_id = c.id) as total_due,
        (SELECT COALESCE(SUM(grand_total),0) FROM sales WHERE client_id = c.id) as total_business
        FROM clients c WHERE c.is_active = 1 ORDER BY total_due DESC";
$clients = $conn->query($sql)->fetch_all(MYSQLI_ASSOC);

$totalDue = 0; $totalBusiness = 0;
foreach ($clients as $c) { $totalDue += $c['total_due']; $totalBusiness += $c['total_business']; }

include '../includes/header.php';
?>

<style>
    @media print {
        body * { visibility: hidden; }
        .print-area, .print-area * { visibility: visible; }
        .print-area { position: absolute; left: 0; top: 0; width: 100%; background: white; color: black; padding: 20px; }
        .print-area .text-white { color: black !important; }
        .print-area .text-slate-400 { color: #555 !important; }
        .print-area .text-emerald-300 { color: #047857 !important; }
        .print-area .text-rose-300 { color: #b91c1c !important; }
        .print-area .bg-white\/5 { background: #f3f4f6 !important; }
        .print-area .border-white\/10 { border-color: #e5e7eb !important; }
        .print-area .glass-dark { background: white !important; border: 1px solid #ccc !important; }
        .no-print { display: none !important; }
    }
</style>

<div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5 no-print">
    <div><h1 class="text-2xl font-bold text-white">Client Report</h1></div>
    <div class="flex gap-2">
        <button onclick="window.print()" class="px-4 py-2 rounded-lg bg-indigo-500/20 border border-indigo-500/30 text-indigo-300 text-xs font-semibold"><i class="fas fa-print mr-1"></i> Print</button>
        <button onclick="exportCSV()" class="px-4 py-2 rounded-lg bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-xs font-semibold"><i class="fas fa-file-excel mr-1"></i> Excel</button>
    </div>
</div>

<div class="print-area">
    <div class="hidden print:block mb-6 text-center"><h2 class="text-2xl font-bold">PrintERP</h2><p class="text-sm">Client Dues Report as on <?= date('d M Y') ?></p><hr class="my-3"></div>

    <div class="grid grid-cols-2 gap-3 mb-5">
        <div class="glass-dark rounded-xl p-4 border border-white/10"><div class="text-[10px] text-slate-400 uppercase">Total Business</div><div class="text-xl font-bold text-white mt-1"><?= money($totalBusiness) ?></div></div>
        <div class="glass-dark rounded-xl p-4 border border-white/10"><div class="text-[10px] text-slate-400 uppercase">Total Outstanding</div><div class="text-xl font-bold text-rose-300 mt-1"><?= money($totalDue) ?></div></div>
    </div>

    <div class="glass-dark rounded-2xl overflow-hidden">
        <table class="w-full text-xs" id="reportTable">
            <thead><tr class="text-left border-b border-white/10 bg-white/5">
                <th class="px-4 py-3 text-slate-400">Client Name</th><th class="px-4 py-3 text-slate-400">Phone</th>
                <th class="px-4 py-3 text-slate-400 text-right">Total Business</th><th class="px-4 py-3 text-slate-400 text-right">Total Due</th>
            </tr></thead>
            <tbody>
                <?php foreach ($clients as $c): ?>
                <tr class="border-b border-white/5">
                    <td class="px-4 py-2 text-white"><?= e($c['client_name']) ?></td>
                    <td class="px-4 py-2 text-slate-300"><?= e($c['phone'] ?? '-') ?></td>
                    <td class="px-4 py-2 text-right text-slate-300"><?= money($c['total_business']) ?></td>
                    <td class="px-4 py-2 text-right <?= $c['total_due'] > 0 ? 'text-rose-400' : 'text-slate-500' ?>"><?= money($c['total_due']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
function exportCSV() {
    let csv = ["Client,Phone,Total Business,Total Due"];
    document.querySelectorAll('#reportTable tbody tr').forEach(row => {
        let cols = row.querySelectorAll('td');
        if (cols.length === 4) csv.push(Array.from(cols).map(c => '"' + c.innerText.replace(/₹|,/g, '').trim() + '"').join(","));
    });
    const blob = new Blob([csv.join("\n")], { type: "text/csv" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "client_report.csv"; a.click();
}
</script>
<?php include '../includes/footer.php'; ?>