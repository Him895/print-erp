<?php
// ============================================================
// FILE: reports/sales_report.php
// ============================================================
require_once '../config/config.php';
require_login();

$page_title = 'Sales Report';

// Default Date Range (This Month)
$from_date = $_GET['from'] ?? date('Y-m-01');
$to_date   = $_GET['to'] ?? date('Y-m-d');

// Fetch Sales Data with Profit Calculation
$sql = "SELECT 
            s.id, s.sale_no, s.sale_date, s.grand_total, s.paid_amount, s.due_amount, s.payment_mode,
            c.client_name,
            (SELECT COALESCE(SUM(si.qty * p.purchase_price), 0) FROM sale_items si JOIN products p ON si.product_id = p.id WHERE si.sale_id = s.id) as total_cost
        FROM sales s
        LEFT JOIN clients c ON s.client_id = c.id
        WHERE s.sale_date BETWEEN ? AND ? AND s.status != 'cancelled'
        ORDER BY s.sale_date DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param('ss', $from_date, $to_date);
$stmt->execute();
$sales = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Summary Calculations
$totalRevenue = 0;
$totalCost = 0;
$totalPaid = 0;
$totalDue = 0;

foreach ($sales as $s) {
    $totalRevenue += $s['grand_total'];
    $totalCost += $s['total_cost'];
    $totalPaid += $s['paid_amount'];
    $totalDue += $s['due_amount'];
}
$totalProfit = $totalRevenue - $totalCost;

include '../includes/header.php';
?>

<style>
    @media print {
        body * { visibility: hidden; }
        .print-area, .print-area * { visibility: visible; }
        .print-area { position: absolute; left: 0; top: 0; width: 100%; background: white; color: black; padding: 20px; }
        .print-area .text-white { color: black !important; }
        .print-area .text-slate-400 { color: #555 !important; }
        .print-area .text-emerald-300 { color: #047857 !important; }
        .print-area .text-indigo-300 { color: #4338ca !important; }
        .print-area .text-amber-300 { color: #b45309 !important; }
        .print-area .bg-white\/5 { background: #f3f4f6 !important; }
        .print-area .border-white\/10 { border-color: #e5e7eb !important; }
        .print-area .glass-dark { background: white !important; border: 1px solid #ccc !important; }
        .no-print { display: none !important; }
    }
</style>

<div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5 no-print">
    <div>
        <h1 class="text-2xl font-bold text-white tracking-tight">Sales Report</h1>
        <p class="text-xs text-slate-400 mt-0.5">Date-wise sales, profit & payment analysis</p>
    </div>
    <div class="flex gap-2">
        <button onclick="window.print()" class="px-4 py-2 rounded-lg bg-indigo-500/20 border border-indigo-500/30 text-indigo-300 text-xs font-semibold hover:bg-indigo-500/30 transition">
            <i class="fas fa-print mr-1"></i> Print / PDF
        </button>
        <button onclick="exportCSV()" class="px-4 py-2 rounded-lg bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-xs font-semibold hover:bg-emerald-500/30 transition">
            <i class="fas fa-file-excel mr-1"></i> Export Excel
        </button>
    </div>
</div>

<!-- Filters -->
<form method="GET" class="glass-dark rounded-2xl p-4 mb-5 flex flex-wrap gap-3 items-end no-print">
    <div>
        <label class="text-[10px] text-slate-400 block mb-1">From Date</label>
        <input type="date" name="from" value="<?= e($from_date) ?>" class="bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-slate-200 outline-none">
    </div>
    <div>
        <label class="text-[10px] text-slate-400 block mb-1">To Date</label>
        <input type="date" name="to" value="<?= e($to_date) ?>" class="bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-slate-200 outline-none">
    </div>
    <button type="submit" class="px-4 py-2 rounded-lg bg-indigo-500 text-white text-xs font-semibold hover:bg-indigo-600 transition">
        Apply Filter
    </button>
</form>

<!-- Printable Area -->
<div class="print-area">
    
    <!-- Report Header (For Print) -->
    <div class="hidden print:block mb-6 text-center">
        <h2 class="text-2xl font-bold">PrintERP</h2>
        <p class="text-sm">Sales Report from <?= fmt_date($from_date) ?> to <?= fmt_date($to_date) ?></p>
        <hr class="my-3">
    </div>

    <!-- Summary Cards -->
    <div class="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
        <div class="glass-dark rounded-xl p-4 border border-white/10">
            <div class="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">Total Revenue</div>
            <div class="text-2xl font-bold text-emerald-300 mt-1"><?= money($totalRevenue) ?></div>
        </div>
        <div class="glass-dark rounded-xl p-4 border border-white/10">
            <div class="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">Est. Cost</div>
            <div class="text-2xl font-bold text-rose-300 mt-1"><?= money($totalCost) ?></div>
        </div>
        <div class="glass-dark rounded-xl p-4 border border-white/10">
            <div class="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">Est. Profit</div>
            <div class="text-2xl font-bold text-indigo-300 mt-1"><?= money($totalProfit) ?></div>
        </div>
        <div class="glass-dark rounded-xl p-4 border border-white/10">
            <div class="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">Total Due</div>
            <div class="text-2xl font-bold text-amber-300 mt-1"><?= money($totalDue) ?></div>
        </div>
    </div>

    <!-- Data Table -->
    <div class="glass-dark rounded-2xl overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-xs" id="reportTable">
                <thead>
                    <tr class="text-left border-b border-white/10 bg-white/5">
                        <th class="px-4 py-3 text-slate-400 font-medium">Date</th>
                        <th class="px-4 py-3 text-slate-400 font-medium">Invoice No</th>
                        <th class="px-4 py-3 text-slate-400 font-medium">Client</th>
                        <th class="px-4 py-3 text-slate-400 font-medium">Mode</th>
                        <th class="px-4 py-3 text-slate-400 font-medium text-right">Revenue</th>
                        <th class="px-4 py-3 text-slate-400 font-medium text-right">Cost</th>
                        <th class="px-4 py-3 text-slate-400 font-medium text-right">Profit</th>
                        <th class="px-4 py-3 text-slate-400 font-medium text-right">Paid</th>
                        <th class="px-4 py-3 text-slate-400 font-medium text-right">Due</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($sales)): ?>
                        <?php foreach ($sales as $s): 
                            $profit = $s['grand_total'] - $s['total_cost'];
                        ?>
                            <tr class="border-b border-white/5">
                                <td class="px-4 py-2 text-slate-300"><?= fmt_date($s['sale_date']) ?></td>
                                <td class="px-4 py-2 text-indigo-300 font-medium"><?= e($s['sale_no']) ?></td>
                                <td class="px-4 py-2 text-white"><?= e($s['client_name'] ?? 'Walk-in') ?></td>
                                <td class="px-4 py-2 text-slate-400 uppercase text-[10px]"><?= e($s['payment_mode']) ?></td>
                                <td class="px-4 py-2 text-right text-white"><?= money($s['grand_total']) ?></td>
                                <td class="px-4 py-2 text-right text-slate-400"><?= money($s['total_cost']) ?></td>
                                <td class="px-4 py-2 text-right <?= $profit >= 0 ? 'text-emerald-400' : 'text-rose-400' ?> font-medium"><?= money($profit) ?></td>
                                <td class="px-4 py-2 text-right text-emerald-300"><?= money($s['paid_amount']) ?></td>
                                <td class="px-4 py-2 text-right <?= $s['due_amount'] > 0 ? 'text-rose-400' : 'text-slate-500' ?>"><?= money($s['due_amount']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="9" class="px-4 py-8 text-center text-slate-500">
                                No sales found in this date range.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
function exportCSV() {
    let csv = [];
    // Headers
    csv.push("Date,Invoice No,Client,Mode,Revenue,Cost,Profit,Paid,Due");
    
    // Rows
    const rows = document.querySelectorAll('#reportTable tbody tr');
    rows.forEach(row => {
        const cols = row.querySelectorAll('td');
        if (cols.length === 9) {
            let rowData = [];
            cols.forEach(col => {
                // Remove rupee symbol and commas for clean CSV
                let text = col.innerText.replace(/₹/g, '').replace(/,/g, '').trim();
                rowData.push('"' + text + '"');
            });
            csv.push(rowData.join(","));
        }
    });

    const csvFile = new Blob([csv.join("\n")], { type: "text/csv" });
    const downloadLink = document.createElement("a");
    downloadLink.download = "sales_report_<?= $from_date ?>_to_<?= $to_date ?>.csv";
    downloadLink.href = window.URL.createObjectURL(csvFile);
    downloadLink.style.display = "none";
    document.body.appendChild(downloadLink);
    downloadLink.click();
}
</script>

<?php include '../includes/footer.php'; ?>