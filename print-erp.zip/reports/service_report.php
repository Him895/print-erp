<?php
require_once '../config/config.php';
require_login();
$page_title = 'Service Report';

$from_date = $_GET['from'] ?? date('Y-m-01');
$to_date   = $_GET['to'] ?? date('Y-m-d');

$sql = "SELECT sv.*, c.client_name FROM services sv 
        LEFT JOIN clients c ON sv.client_id = c.id 
        WHERE sv.service_date BETWEEN ? AND ? ORDER BY sv.service_date DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param('ss', $from_date, $to_date);
$stmt->execute();
$services = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$totalAmount = 0; $totalJobs = count($services);
foreach ($services as $s) { $totalAmount += $s['total_amount']; }

include '../includes/header.php';
?>

<style>
    @media print {
        body * { visibility: hidden; }
        .print-area, .print-area * { visibility: visible; }
        .print-area { position: absolute; left: 0; top: 0; width: 100%; background: white; color: black; padding: 20px; }
        .print-area .text-white { color: black !important; }
        .print-area .text-slate-400 { color: #555 !important; }
        .print-area .text-emerald-300 { color: #047857 !important; }
        .print-area .bg-white\/5 { background: #f3f4f6 !important; }
        .print-area .border-white\/10 { border-color: #e5e7eb !important; }
        .print-area .glass-dark { background: white !important; border: 1px solid #ccc !important; }
        .no-print { display: none !important; }
    }
</style>

<div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5 no-print">
    <div><h1 class="text-2xl font-bold text-white">Service Report</h1></div>
    <div class="flex gap-2">
        <button onclick="window.print()" class="px-4 py-2 rounded-lg bg-indigo-500/20 border border-indigo-500/30 text-indigo-300 text-xs font-semibold"><i class="fas fa-print mr-1"></i> Print</button>
        <button onclick="exportCSV()" class="px-4 py-2 rounded-lg bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-xs font-semibold"><i class="fas fa-file-excel mr-1"></i> Excel</button>
    </div>
</div>

<form method="GET" class="glass-dark rounded-2xl p-4 mb-5 flex flex-wrap gap-3 no-print">
    <div><label class="text-[10px] text-slate-400 block mb-1">From</label><input type="date" name="from" value="<?= e($from_date) ?>" class="bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-slate-200"></div>
    <div><label class="text-[10px] text-slate-400 block mb-1">To</label><input type="date" name="to" value="<?= e($to_date) ?>" class="bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-slate-200"></div>
    <button type="submit" class="px-4 py-2 rounded-lg bg-indigo-500 text-white text-xs font-semibold mt-4">Apply</button>
</form>

<div class="print-area">
    <div class="hidden print:block mb-6 text-center"><h2 class="text-2xl font-bold">PrintERP</h2><p class="text-sm">Service Report (<?= fmt_date($from_date) ?> to <?= fmt_date($to_date) ?>)</p><hr class="my-3"></div>

    <div class="grid grid-cols-2 gap-3 mb-5">
        <div class="glass-dark rounded-xl p-4 border border-white/10"><div class="text-[10px] text-slate-400 uppercase">Total Jobs</div><div class="text-xl font-bold text-white mt-1"><?= $totalJobs ?></div></div>
        <div class="glass-dark rounded-xl p-4 border border-white/10"><div class="text-[10px] text-slate-400 uppercase">Total Revenue</div><div class="text-xl font-bold text-emerald-300 mt-1"><?= money($totalAmount) ?></div></div>
    </div>

    <div class="glass-dark rounded-2xl overflow-hidden">
        <table class="w-full text-xs" id="reportTable">
            <thead><tr class="text-left border-b border-white/10 bg-white/5">
                <th class="px-4 py-3 text-slate-400">Date</th><th class="px-4 py-3 text-slate-400">Job No</th><th class="px-4 py-3 text-slate-400">Client</th>
                <th class="px-4 py-3 text-slate-400">Type</th><th class="px-4 py-3 text-slate-400 text-center">Status</th><th class="px-4 py-3 text-slate-400 text-right">Amount</th>
            </tr></thead>
            <tbody>
                <?php foreach ($services as $s): ?>
                <tr class="border-b border-white/5">
                    <td class="px-4 py-2 text-slate-300"><?= fmt_date($s['service_date']) ?></td>
                    <td class="px-4 py-2 text-indigo-300"><?= e($s['service_no']) ?></td>
                    <td class="px-4 py-2 text-white"><?= e($s['client_name'] ?? 'Walk-in') ?></td>
                    <td class="px-4 py-2 text-slate-400 text-[10px] uppercase"><?= e($s['service_type']) ?></td>
                    <td class="px-4 py-2 text-center text-[10px] uppercase"><?= str_replace('_', ' ', $s['status']) ?></td>
                    <td class="px-4 py-2 text-right text-emerald-300"><?= money($s['total_amount']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
function exportCSV() {
    let csv = ["Date,Job No,Client,Type,Status,Amount"];
    document.querySelectorAll('#reportTable tbody tr').forEach(row => {
        let cols = row.querySelectorAll('td');
        if (cols.length === 6) csv.push(Array.from(cols).map(c => '"' + c.innerText.replace(/₹|,/g, '').trim() + '"').join(","));
    });
    const blob = new Blob([csv.join("\n")], { type: "text/csv" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "service_report.csv"; a.click();
}
</script>
<?php include '../includes/footer.php'; ?>