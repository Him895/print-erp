<?php
// ============================================================
// FILE: payments/add_payment.php
// ============================================================
require_once '../config/config.php';
require_login();

$page_title = 'Add Payment';
$error = '';

$type = $_GET['type'] ?? 'receivable';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $type         = $_POST['type'] ?? 'receivable';
    $ref_id       = (int)($_POST['ref_id'] ?? 0);
    $amount       = (float)($_POST['amount'] ?? 0);
    $payment_mode = $_POST['payment_mode'] ?? 'cash';
    $payment_date = trim($_POST['payment_date'] ?? date('Y-m-d'));
    $notes        = trim($_POST['notes'] ?? '');

    if ($ref_id <= 0 || $amount <= 0) {
        $error = 'Please select an invoice and enter a valid amount.';
    } else {
        $conn->begin_transaction();
        try {
            $payment_no = generate_no($conn, 'payments', 'payment_no', 'PAY');
            
            if ($type === 'receivable') {
                // Customer se paisa aa raha hai (Sale)
                $stmt = $conn->prepare("SELECT * FROM sales WHERE id = ?");
                $stmt->bind_param('i', $ref_id);
                $stmt->execute();
                $ref = $stmt->get_result()->fetch_assoc();
                $stmt->close();

                if (!$ref) throw new Exception('Sale not found.');
                if ($amount > $ref['due_amount']) throw new Exception('Amount exceeds due amount.');

                // Insert Payment (client_id set)
                $stmt = $conn->prepare("INSERT INTO payments (payment_no, ref_type, ref_id, client_id, amount, payment_mode, payment_date, status, notes) VALUES (?, 'sale', ?, ?, ?, ?, ?, 'confirmed', ?)");
                $stmt->bind_param('siisdss', $payment_no, $ref_id, $ref['client_id'], $amount, $payment_mode, $payment_date, $notes);
                $stmt->execute();
                $stmt->close();

                // Update Sale
                $new_paid = $ref['paid_amount'] + $amount;
                $new_due = $ref['due_amount'] - $amount;
                $new_status = ($new_due <= 0) ? 'completed' : 'pending';
                $upd = $conn->prepare("UPDATE sales SET paid_amount=?, due_amount=?, status=? WHERE id=?");
                $upd->bind_param('ddsi', $new_paid, $new_due, $new_status, $ref_id);
                $upd->execute();
                $upd->close();

            } else {
                // Vendor ko paisa de raha hai (Purchase)
                $stmt = $conn->prepare("SELECT * FROM product_purchase WHERE id = ?");
                $stmt->bind_param('i', $ref_id);
                $stmt->execute();
                $ref = $stmt->get_result()->fetch_assoc();
                $stmt->close();

                if (!$ref) throw new Exception('Purchase not found.');
                if ($amount > $ref['due_amount']) throw new Exception('Amount exceeds due amount.');

                // Insert Payment (client_id me NULL jayega)
                $stmt = $conn->prepare("INSERT INTO payments (payment_no, ref_type, ref_id, client_id, amount, payment_mode, payment_date, status, notes) VALUES (?, 'purchase', ?, NULL, ?, ?, ?, 'confirmed', ?)");
                $stmt->bind_param('siidss', $payment_no, $ref_id, $amount, $payment_mode, $payment_date, $notes);
                $stmt->execute();
                $stmt->close();

                // Update Purchase
                $new_paid = $ref['paid_amount'] + $amount;
                $new_due = $ref['due_amount'] - $amount;
                $upd = $conn->prepare("UPDATE product_purchase SET paid_amount=?, due_amount=? WHERE id=?");
                $upd->bind_param('ddi', $new_paid, $new_due, $ref_id);
                $upd->execute();
                $upd->close();
            }

            $conn->commit();
            set_flash('success', "Payment ($payment_no) recorded successfully!");
            redirect('payments_list.php');

        } catch (Exception $e) {
            $conn->rollback();
            $error = $e->getMessage();
        }
    }
}

// Fetch Pending Invoices
if ($type === 'receivable') {
    $invoices = $conn->query("SELECT s.id, s.sale_no as no, s.due_amount, c.client_name as name FROM sales s LEFT JOIN clients c ON s.client_id = c.id WHERE s.due_amount > 0")->fetch_all(MYSQLI_ASSOC);
} else {
    $invoices = $conn->query("SELECT p.id, p.purchase_no as no, p.due_amount, v.vendor_name as name FROM product_purchase p LEFT JOIN vendors v ON p.vendor_id = v.id WHERE p.due_amount > 0")->fetch_all(MYSQLI_ASSOC);
}

include '../includes/header.php';
?>

<div class="flex items-center justify-between gap-3 mb-5">
    <div>
        <h1 class="text-2xl font-bold text-white">Add Payment</h1>
        <p class="text-xs text-slate-400 mt-0.5">Record payment manually</p>
    </div>
    <a href="payments_list.php" class="px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-slate-300 text-xs hover:bg-white/10 transition">
        <i class="fas fa-arrow-left mr-1"></i> Back
    </a>
</div>

<!-- Type Toggle -->
<div class="flex gap-2 mb-5">
    <a href="?type=receivable" class="px-4 py-2 rounded-lg text-sm font-semibold transition <?= $type === 'receivable' ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/20' : 'bg-white/5 text-slate-400 hover:bg-white/10' ?>">
        <i class="fas fa-arrow-down mr-1"></i> Receive (Customer)
    </a>
    <a href="?type=payable" class="px-4 py-2 rounded-lg text-sm font-semibold transition <?= $type === 'payable' ? 'bg-rose-500 text-white shadow-lg shadow-rose-500/20' : 'bg-white/5 text-slate-400 hover:bg-white/10' ?>">
        <i class="fas fa-arrow-up mr-1"></i> Pay (Vendor)
    </a>
</div>

<?php if ($error): ?>
    <div class="mb-4 rounded-xl p-3 text-sm bg-rose-500/15 border border-rose-500/30 text-rose-300">
        <i class="fas fa-exclamation-circle mr-2"></i><?= e($error) ?>
    </div>
<?php endif; ?>

<form method="POST" class="glass-dark rounded-2xl p-5 max-w-2xl">
    <input type="hidden" name="type" value="<?= $type ?>">
    <div class="space-y-4">
        <div>
            <label class="text-xs text-slate-400 mb-1 block">Select Pending Invoice *</label>
            <select name="ref_id" required onchange="updateAmount(this)" class="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-slate-200 outline-none focus:border-indigo-500/50">
                <option value="">-- Select --</option>
                <?php foreach ($invoices as $inv): ?>
                    <option value="<?= $inv['id'] ?>" data-due="<?= $inv['due_amount'] ?>">
                        <?= e($inv['no']) ?> - <?= e($inv['name']) ?> (Due: <?= money($inv['due_amount']) ?>)
                    </option>
                <?php endforeach; ?>
            </select>
            <?php if(empty($invoices)): ?>
                <p class="text-[10px] text-rose-400 mt-1"><i class="fas fa-info-circle"></i> Koi pending invoice nahi hai.</p>
            <?php endif; ?>
        </div>

        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="text-xs text-slate-400 mb-1 block">Amount (₹) *</label>
                <input type="number" step="1" name="amount" id="amountInput" required class="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white font-bold outline-none focus:border-indigo-500/50">
            </div>
            <div>
                <label class="text-xs text-slate-400 mb-1 block">Payment Mode</label>
                <select name="payment_mode" class="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-slate-200 outline-none">
                    <option value="cash">Cash</option>
                    <option value="upi">UPI</option>
                    <option value="bank">Bank</option>
                </select>
            </div>
        </div>

        <div>
            <label class="text-xs text-slate-400 mb-1 block">Date</label>
            <input type="date" name="payment_date" required value="<?= date('Y-m-d') ?>" class="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-slate-200 outline-none">
        </div>

        <div>
            <label class="text-xs text-slate-400 mb-1 block">Notes (Optional)</label>
            <input type="text" name="notes" placeholder="e.g. Cash received from Ramesh" class="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-slate-200 outline-none">
        </div>

        <button type="submit" class="w-full py-2.5 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-500 text-white text-sm font-semibold mt-4 <?= empty($invoices) ? 'opacity-50 cursor-not-allowed' : '' ?>" <?= empty($invoices) ? 'disabled' : '' ?>>
            <i class="fas fa-save mr-1"></i> Save Payment
        </button>
    </div>
</form>

<script>
function updateAmount(select) {
    const due = select.options[select.selectedIndex].getAttribute('data-due');
    if (due) document.getElementById('amountInput').value = Math.round(due);
}
</script>

<style>
    select { background-color: #1e293b !important; color: #fff !important; }
    select option { background-color: #1e293b !important; color: #fff !important; }
</style>

<?php include '../includes/footer.php'; ?>