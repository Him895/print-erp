<?php
// ============================================================
// FILE: payments/payments_list.php
// ============================================================
require_once '../config/config.php';
require_login();

$page_title = 'Payments';

// Fetch All Transactions (Sale Paid, Purchase Paid, and Additional Payments)
$sql = "
    -- 1. Sales ke time jo paid_amount diya
    SELECT 
        CONCAT('SAL-', s.id) as unique_id,
        s.sale_no as ref_no, 
        s.sale_date as date, 
        c.client_name as party_name, 
        'Receivable' as type,
        s.paid_amount as amount,
        s.due_amount as due,
        s.payment_mode,
        s.status,
        'Sale' as module
    FROM sales s
    LEFT JOIN clients c ON s.client_id = c.id
    WHERE s.paid_amount > 0 OR s.due_amount > 0

    UNION ALL

    -- 2. Purchases ke time jo paid_amount diya
    SELECT 
        CONCAT('PUR-', p.id) as unique_id,
        p.purchase_no as ref_no, 
        p.purchase_date as date, 
        v.vendor_name as party_name, 
        'Payable' as type,
        p.paid_amount as amount,
        p.due_amount as due,
        p.payment_mode,
        'completed' as status,
        'Purchase' as module
    FROM product_purchase p
    LEFT JOIN vendors v ON p.vendor_id = v.id
    WHERE p.paid_amount > 0 OR p.due_amount > 0

    UNION ALL

    -- 3. Baad me kiye gaye extra payments (Add Payment se)
    SELECT 
        CONCAT('PAY-', pay.id) as unique_id,
        pay.payment_no as ref_no, 
        pay.payment_date as date, 
        COALESCE(c.client_name, v.vendor_name, 'Unknown') as party_name, 
        IF(pay.ref_type = 'sale', 'Receivable', 'Payable') as type,
        pay.amount,
        0 as due, -- Extra payment me due 0 maan rahe hain kyunki ye recovery hai
        pay.payment_mode,
        pay.status,
        IF(pay.ref_type = 'sale', 'Sale', 'Purchase') as module
    FROM payments pay
    LEFT JOIN sales s ON pay.ref_type = 'sale' AND pay.ref_id = s.id
    LEFT JOIN clients c ON s.client_id = c.id
    LEFT JOIN product_purchase p ON pay.ref_type = 'purchase' AND pay.ref_id = p.id
    LEFT JOIN vendors v ON p.vendor_id = v.id
    WHERE pay.status = 'confirmed'
    
    ORDER BY date DESC, unique_id DESC
";

$transactions = $conn->query($sql)->fetch_all(MYSQLI_ASSOC);

// Summary
$totalReceivable = 0;
$totalPayable = 0;
foreach ($transactions as $t) {
    if ($t['type'] === 'Receivable') $totalReceivable += $t['amount'];
    else $totalPayable += $t['amount'];
}

include '../includes/header.php';
?>

<div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5">
    <div>
        <h1 class="text-2xl font-bold text-white tracking-tight">Payments Ledger</h1>
        <p class="text-xs text-slate-400 mt-0.5">Saari aayi aur gayi payments ka hisaab</p>
    </div>
    <div class="flex gap-2">
        <a href="add_payment.php?type=receivable" class="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-sm font-semibold hover:bg-emerald-500/30 transition-all">
            <i class="fas fa-arrow-down"></i> Receive (Customer)
        </a>
        <a href="add_payment.php?type=payable" class="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-rose-500/20 border border-rose-500/30 text-rose-300 text-sm font-semibold hover:bg-rose-500/30 transition-all">
            <i class="fas fa-arrow-up"></i> Pay (Vendor)
        </a>
    </div>
</div>

<div class="grid grid-cols-2 gap-3 mb-5">
    <div class="glass-dark rounded-xl p-4 border border-white/10">
        <div class="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">Total Received (Aayaa)</div>
        <div class="text-2xl font-bold bg-gradient-to-r from-emerald-300 to-emerald-500 bg-clip-text text-transparent mt-1"><?= money($totalReceivable) ?></div>
    </div>
    <div class="glass-dark rounded-xl p-4 border border-white/10">
        <div class="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">Total Paid (Gayaa)</div>
        <div class="text-2xl font-bold bg-gradient-to-r from-rose-300 to-rose-500 bg-clip-text text-transparent mt-1"><?= money($totalPayable) ?></div>
    </div>
</div>

<div class="glass-dark rounded-2xl overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full text-xs">
            <thead>
                <tr class="text-left border-b border-white/10 bg-white/3">
                    <th class="px-4 py-3 text-slate-400 font-medium">Date</th>
                    <th class="px-4 py-3 text-slate-400 font-medium">Ref No</th>
                    <th class="px-4 py-3 text-slate-400 font-medium">Party (Client/Vendor)</th>
                    <th class="px-4 py-3 text-slate-400 font-medium">Module</th>
                    <th class="px-4 py-3 text-slate-400 font-medium">Mode</th>
                    <th class="px-4 py-3 text-slate-400 font-medium text-right">In (Receivable)</th>
                    <th class="px-4 py-3 text-slate-400 font-medium text-right">Out (Payable)</th>
                    <th class="px-4 py-3 text-slate-400 font-medium text-right">Due Balance</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($transactions)): ?>
                    <?php foreach ($transactions as $t): ?>
                        <tr class="border-b border-white/5 hover:bg-white/3 transition">
                            <td class="px-4 py-3 text-slate-300"><?= fmt_date($t['date']) ?></td>
                            <td class="px-4 py-3">
                                <span class="px-2 py-0.5 rounded bg-white/5 border border-white/10 text-[10px] font-mono text-slate-300">
                                    <?= e($t['ref_no']) ?>
                                </span>
                            </td>
                            <td class="px-4 py-3 text-white font-medium"><?= e($t['party_name']) ?></td>
                            <td class="px-4 py-3">
                                <?php if($t['module'] == 'Sale'): ?>
                                    <span class="text-indigo-300"><i class="fas fa-file-invoice-dollar mr-1"></i> Sale</span>
                                <?php else: ?>
                                    <span class="text-amber-300"><i class="fas fa-shopping-cart mr-1"></i> Purchase</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-4 py-3 text-slate-400 uppercase text-[10px]"><?= e($t['payment_mode']) ?></td>
                            
                            <!-- Amount IN -->
                            <td class="px-4 py-3 text-right">
                                <?php if($t['type'] == 'Receivable' && $t['amount'] > 0): ?>
                                    <span class="text-emerald-300 font-bold text-sm">+<?= money($t['amount']) ?></span>
                                <?php else: ?>
                                    <span class="text-slate-600">-</span>
                                <?php endif; ?>
                            </td>

                            <!-- Amount OUT -->
                            <td class="px-4 py-3 text-right">
                                <?php if($t['type'] == 'Payable' && $t['amount'] > 0): ?>
                                    <span class="text-rose-300 font-bold text-sm">-<?= money($t['amount']) ?></span>
                                <?php else: ?>
                                    <span class="text-slate-600">-</span>
                                <?php endif; ?>
                            </td>

                            <!-- Due Amount -->
                            <td class="px-4 py-3 text-right">
                                <?php if($t['due'] > 0): ?>
                                    <span class="text-amber-400 font-bold"><?= money($t['due']) ?></span>
                                <?php else: ?>
                                    <span class="text-emerald-500 text-[10px]"><i class="fas fa-check-circle"></i> Clear</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8">
                            <div class="text-center py-12 text-slate-500">
                                <i class="fas fa-money-bill-wave text-3xl block mb-2 opacity-30"></i>
                                <div class="text-sm">No transactions yet</div>
                            </div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include '../includes/footer.php'; ?>