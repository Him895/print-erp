<?php
// ============================================================
// FILE: sales/update_sale.php
// ============================================================
require_once '../config/config.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('sales_list.php');
}

$sale_id = (int)($_POST['sale_id'] ?? 0);
if ($sale_id <= 0) redirect('sales_list.php');

$client_id   = (int)($_POST['client_id'] ?? 0);
$sale_date   = trim($_POST['sale_date'] ?? date('Y-m-d'));
$gst_percent = (float)($_POST['gst_percent'] ?? 0);
$payment_mode = $_POST['payment_mode'] ?? 'cash';
$paid_amount  = (float)($_POST['paid_amount'] ?? 0);

$item_product_ids = $_POST['product_id'] ?? [];
$item_qtys        = $_POST['qty'] ?? [];
$item_rates       = $_POST['rate'] ?? []; 
$item_print_charges = $_POST['print_charge'] ?? [];
$item_print_types = $_POST['print_type'] ?? [];
$item_print_notes = $_POST['print_notes'] ?? [];

// 1. Fetch Old Items to Revert Stock
$stmt = $conn->prepare("SELECT product_id, qty FROM sale_items WHERE sale_id = ?");
$stmt->bind_param('i', $sale_id);
$stmt->execute();
$old_items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$conn->begin_transaction();

try {
    // 2. Revert Old Stock (+)
    $revertStock = $conn->prepare("UPDATE products SET stock_qty = stock_qty + ? WHERE id = ?");
    foreach ($old_items as $item) {
        $revertStock->bind_param('ii', $item['qty'], $item['product_id']);
        $revertStock->execute();
    }
    $revertStock->close();

    // 3. Calculate New Totals
    $product_total = 0;
    $print_total = 0;
    $items_to_save = [];
    
    foreach ($item_product_ids as $index => $p_id) {
        $p_id = (int)$p_id;
        $qty = (int)($item_qtys[$index] ?? 0);
        $rate = (float)($item_rates[$index] ?? 0);
        $print_charge = (float)($item_print_charges[$index] ?? 0);
        $print_type = trim($item_print_types[$index] ?? '');
        $print_notes = trim($item_print_notes[$index] ?? '');
        
        if ($p_id > 0 && $qty > 0 && $rate > 0) {
            $amount = $qty * $rate;
            $product_total += $amount;
            $print_total += $print_charge;
            
            $items_to_save[] = [
                'product_id' => $p_id,
                'qty' => $qty,
                'rate' => $rate,
                'amount' => $amount,
                'print_charge' => $print_charge,
                'print_type' => $print_type,
                'print_notes' => $print_notes
            ];
        }
    }

    if (empty($items_to_save)) {
        throw new Exception('Kam se kam ek valid product hona chahiye.');
    }

    $sub_total = $product_total + $print_total;
    $gst_amount = ($sub_total * $gst_percent) / 100;
    $grand_total = $sub_total + $gst_amount;
    
    $due_amount = $grand_total - $paid_amount;
    $status = ($due_amount <= 0) ? 'completed' : 'pending';
    if ($due_amount < 0) $due_amount = 0;

    // 4. Update Sale Table
    $stmt = $conn->prepare("UPDATE sales SET 
        client_id=?, product_total=?, print_total=?, sub_total=?, gst_percent=?, gst_amount=?, grand_total=?, 
        status=?, payment_mode=?, paid_amount=?, due_amount=?, sale_date=? WHERE id=?");
    $stmt->bind_param('iddddddssddsi', $client_id, $product_total, $print_total, $sub_total, $gst_percent, $gst_amount, $grand_total, $status, $payment_mode, $paid_amount, $due_amount, $sale_date, $sale_id);
    $stmt->execute();
    $stmt->close();

    // 5. Delete Old Items
    $stmt = $conn->prepare("DELETE FROM sale_items WHERE sale_id = ?");
    $stmt->bind_param('i', $sale_id);
    $stmt->execute();
    $stmt->close();

    // 6. Insert New Items & Deduct Stock (-)
    $itemStmt = $conn->prepare("INSERT INTO sale_items (sale_id, product_id, qty, rate, amount, print_charge_total, print_type, print_notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stockStmt = $conn->prepare("UPDATE products SET stock_qty = stock_qty - ? WHERE id = ?");

    foreach ($items_to_save as $item) {
        $itemStmt->bind_param('iiidddss', $sale_id, $item['product_id'], $item['qty'], $item['rate'], $item['amount'], $item['print_charge'], $item['print_type'], $item['print_notes']);
        $itemStmt->execute();

        $stockStmt->bind_param('ii', $item['qty'], $item['product_id']);
        $stockStmt->execute();
    }
    $itemStmt->close();
    $stockStmt->close();

    // 7. Handle Service Job Update
    // (Purana service delete karke naya banayenge, simple logic)
    $stmt = $conn->prepare("SELECT service_job_id FROM sales WHERE id = ?");
    $stmt->bind_param('i', $sale_id);
    $stmt->execute();
    $old_srv_id = $stmt->get_result()->fetch_assoc()['service_job_id'];
    $stmt->close();

    if ($old_srv_id) {
        $del = $conn->prepare("DELETE FROM services WHERE id = ?");
        $del->bind_param('i', $old_srv_id);
        $del->execute();
        $del->close();
        
        // Remove mapping
        $upd = $conn->prepare("UPDATE sales SET service_job_id = NULL WHERE id = ?");
        $upd->bind_param('i', $sale_id);
        $upd->execute();
        $upd->close();
    }

    if ($print_total > 0 && $client_id > 0) {
        $service_no = generate_no($conn, 'services', 'service_no', 'SRV');
        
        $combined_notes = "Auto-generated from Sale (Edited): $sale_id\n\nPrint Details:\n";
        foreach ($items_to_save as $item) {
            if ($item['print_charge'] > 0) {
                $combined_notes .= "- Type: {$item['print_type']}, Notes: {$item['print_notes']}\n";
            }
        }
        
        $srvStmt = $conn->prepare("INSERT INTO services 
            (service_no, client_id, sale_id, service_type, qty, print_charge_per_pc, total_amount, notes, status, service_date) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?)");
        
        $srv_qty = 1; 
        $srv_rate = $print_total;
        $srv_type = 'custom_print'; 
        
        $srvStmt->bind_param('siisiddss', $service_no, $client_id, $sale_id, $srv_type, $srv_qty, $srv_rate, $print_total, $combined_notes, $sale_date);
        $srvStmt->execute();
        $new_service_id = $srvStmt->insert_id;
        $srvStmt->close();

        $updSale = $conn->prepare("UPDATE sales SET service_job_id = ? WHERE id = ?");
        $updSale->bind_param('ii', $new_service_id, $sale_id);
        $updSale->execute();
        $updSale->close();
    }

    $conn->commit();
    set_flash('success', "Sale updated successfully! Stock adjusted.");
    redirect('sales_list.php');

} catch (Exception $e) {
    $conn->rollback();
    $_SESSION['error'] = 'Error: ' . $e->getMessage();
    header("Location: edit_sale.php?id=" . $sale_id);
    exit();
}
?>