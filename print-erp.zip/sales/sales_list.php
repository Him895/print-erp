<?php
// ============================================================
// FILE: sales/sales_list.php
// ============================================================
require_once '../config/config.php';
require_login();

$page_title = 'Sales';

// Fetch all sales with client name
$sql = "SELECT s.*, c.client_name 
        FROM sales s
        LEFT JOIN clients c ON s.client_id = c.id
        ORDER BY s.created_at DESC";
$sales = $conn->query($sql)->fetch_all(MYSQLI_ASSOC);

// Summary
$totalSales = count($sales);
$totalRevenue = 0;
$totalDue = 0;
foreach ($sales as $s) {
    if ($s['status'] !== 'cancelled') {
        $totalRevenue += $s['grand_total'];
        $totalDue += $s['due_amount'];
    }
}

include '../includes/header.php';
?>

<div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5">
    <div>
        <h1 class="text-2xl font-bold text-white tracking-tight">Sales</h1>
        <p class="text-xs text-slate-400 mt-0.5">Customer orders and invoices</p>
    </div>
    <a href="add_sale.php" class="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-500 text-white text-sm font-semibold hover:-translate-y-0.5 hover:shadow-lg hover:shadow-indigo-500/40 transition-all">
        <i class="fas fa-plus-circle"></i> New Sale
    </a>
</div>

<div class="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
    <div class="glass-dark rounded-xl p-4">
        <div class="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">Total Sales</div>
        <div class="text-2xl font-bold bg-gradient-to-r from-indigo-300 to-indigo-500 bg-clip-text text-transparent mt-1"><?= $totalSales ?></div>
    </div>
    <div class="glass-dark rounded-xl p-4">
        <div class="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">Total Revenue</div>
        <div class="text-2xl font-bold bg-gradient-to-r from-emerald-300 to-emerald-500 bg-clip-text text-transparent mt-1"><?= money($totalRevenue) ?></div>
    </div>
    <div class="glass-dark rounded-xl p-4">
        <div class="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">Total Due (Udhar)</div>
        <div class="text-2xl font-bold bg-gradient-to-r from-rose-300 to-rose-500 bg-clip-text text-transparent mt-1"><?= money($totalDue) ?></div>
    </div>
</div>

<div class="glass-dark rounded-2xl overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full text-xs">
            <thead>
                <tr class="text-left border-b border-white/10 bg-white/3">
                    <th class="px-4 py-3 text-slate-400 font-medium">#</th>
                    <th class="px-4 py-3 text-slate-400 font-medium">Invoice No</th>
                    <th class="px-4 py-3 text-slate-400 font-medium">Client</th>
                    <th class="px-4 py-3 text-slate-400 font-medium text-right">Grand Total</th>
                    <th class="px-4 py-3 text-slate-400 font-medium text-right">Paid</th>
                    <th class="px-4 py-3 text-slate-400 font-medium text-right">Due</th>
                    <th class="px-4 py-3 text-slate-400 font-medium text-center">Status</th>
                    <th class="px-4 py-3 text-slate-400 font-medium">Date</th>
                    <th class="px-4 py-3 text-slate-400 font-medium text-center">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($sales)): ?>
                    <?php foreach ($sales as $i => $s): 
                        $statusClass = 'bg-amber-500/15 text-amber-300'; // default pending
                        if ($s['status'] === 'completed') $statusClass = 'bg-emerald-500/15 text-emerald-300';
                        if ($s['status'] === 'cancelled') $statusClass = 'bg-rose-500/15 text-rose-300';
                    ?>
                        <tr class="border-b border-white/5 hover:bg-white/3 transition">
                            <td class="px-4 py-3 text-slate-500"><?= $i + 1 ?></td>
                            <td class="px-4 py-3 text-indigo-300 font-medium"><?= e($s['sale_no']) ?></td>
                            <td class="px-4 py-3 text-white"><?= e($s['client_name'] ?? 'Walk-in') ?></td>
                            <td class="px-4 py-3 text-right text-white font-medium"><?= money($s['grand_total']) ?></td>
                            <td class="px-4 py-3 text-right text-emerald-300"><?= money($s['paid_amount']) ?></td>
                            <td class="px-4 py-3 text-right text-rose-300 font-semibold"><?= money($s['due_amount']) ?></td>
                            <td class="px-4 py-3 text-center">
                                <span class="px-2 py-0.5 rounded-full <?= $statusClass ?>"><?= ucfirst($s['status']) ?></span>
                            </td>
                            <td class="px-4 py-3 text-slate-400"><?= fmt_date($s['sale_date']) ?></td>
                            <td class="px-4 py-3 text-center">
                                <div class="flex items-center justify-center gap-1.5">
                                    <a href="view_sale.php?id=<?= $s['id'] ?>" class="w-7 h-7 rounded-lg bg-indigo-500/15 text-indigo-300 inline-flex items-center justify-center hover:bg-indigo-500/30 transition" title="View Bill">
                                        <i class="fas fa-eye text-[10px]"></i>
                                    </a>
                                    <a href="edit_sale.php?id=<?= $s['id'] ?>" class="w-7 h-7 rounded-lg bg-amber-500/15 text-amber-300 inline-flex items-center justify-center hover:bg-amber-500/30 transition" title="Edit">
                                        <i class="fas fa-edit text-[10px]"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="9">
                            <div class="text-center py-12 text-slate-500">
                                <i class="fas fa-file-invoice-dollar text-3xl block mb-2 opacity-30"></i>
                                <div class="text-sm">No sales yet</div>
                                <a href="add_sale.php" class="inline-block mt-2 text-indigo-400 hover:text-indigo-300 text-xs underline">Create your first sale →</a>
                            </div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include '../includes/footer.php'; ?>