<?php
// ============================================================
// FILE: sales/add_sale.php (WITH PROPER DROPDOWNS)
// ============================================================
require_once '../config/config.php';
require_login();

$page_title = 'New Sale';
$error = '';

// Fetch Clients & Products
$clients = $conn->query("SELECT * FROM clients WHERE is_active = 1 ORDER BY client_name")->fetch_all(MYSQLI_ASSOC);
$products = $conn->query("SELECT * FROM products WHERE is_active = 1 AND stock_qty > 0 ORDER BY product_name")->fetch_all(MYSQLI_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $client_id   = (int)($_POST['client_id'] ?? 0);
    $sale_date   = trim($_POST['sale_date'] ?? date('Y-m-d'));
    $gst_percent = (float)($_POST['gst_percent'] ?? 0);
    
    $payment_mode = $_POST['payment_mode'] ?? 'cash';
    $paid_amount  = (float)($_POST['paid_amount'] ?? 0);
    
    $item_product_ids = $_POST['product_id'] ?? [];
    $item_qtys        = $_POST['qty'] ?? [];
    $item_rates       = $_POST['rate'] ?? []; 
    $item_print_charges = $_POST['print_charge'] ?? [];
    $item_print_types = $_POST['print_type'] ?? [];
    $item_print_notes = $_POST['print_notes'] ?? [];

    if (empty($item_product_ids)) {
        $error = 'Kam se kam ek product select karein.';
    } else {
        $product_total = 0;
        $print_total = 0;
        $items_to_save = [];
        
        foreach ($item_product_ids as $index => $p_id) {
            $p_id = (int)$p_id;
            $qty = (int)($item_qtys[$index] ?? 0);
            $rate = (float)($item_rates[$index] ?? 0);
            $print_charge = (float)($item_print_charges[$index] ?? 0);
            $print_type = trim($item_print_types[$index] ?? '');
            $print_notes = trim($item_print_notes[$index] ?? '');
            
            if ($p_id > 0 && $qty > 0 && $rate > 0) {
                $amount = $qty * $rate;
                $product_total += $amount;
                $print_total += $print_charge;
                
                $items_to_save[] = [
                    'product_id' => $p_id,
                    'qty' => $qty,
                    'rate' => $rate,
                    'amount' => $amount,
                    'print_charge' => $print_charge,
                    'print_type' => $print_type,
                    'print_notes' => $print_notes
                ];
            }
        }

        if (empty($items_to_save)) {
            $error = 'Sahi product, qty aur rate bharein.';
        } else {
            $sub_total = $product_total + $print_total;
            $gst_amount = ($sub_total * $gst_percent) / 100;
            $grand_total = $sub_total + $gst_amount;
            
            // Agar paid amount 0 hai, toh udhar maana jayega
            $due_amount = $grand_total - $paid_amount;
            $status = ($due_amount <= 0) ? 'completed' : 'pending';
            if ($due_amount < 0) $due_amount = 0; // Overpayment handle
            
            $sale_no = generate_no($conn, 'sales', 'sale_no', 'SAL');

            $conn->begin_transaction();

            try {
                // 1. Insert Sale
                $stmt = $conn->prepare("INSERT INTO sales 
                    (sale_no, client_id, product_total, print_total, sub_total, gst_percent, gst_amount, grand_total, status, payment_mode, paid_amount, due_amount, sale_date) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->bind_param('siddddddssdds', $sale_no, $client_id, $product_total, $print_total, $sub_total, $gst_percent, $gst_amount, $grand_total, $status, $payment_mode, $paid_amount, $due_amount, $sale_date);
                $stmt->execute();
                $sale_id = $stmt->insert_id;
                $stmt->close();

                // 2. Insert Sale Items & Deduct Stock
                $itemStmt = $conn->prepare("INSERT INTO sale_items (sale_id, product_id, qty, rate, amount, print_charge_total, print_type, print_notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $stockStmt = $conn->prepare("UPDATE products SET stock_qty = stock_qty - ? WHERE id = ?");

                foreach ($items_to_save as $item) {
                    $itemStmt->bind_param('iiidddss', $sale_id, $item['product_id'], $item['qty'], $item['rate'], $item['amount'], $item['print_charge'], $item['print_type'], $item['print_notes']);
                    $itemStmt->execute();

                    $stockStmt->bind_param('ii', $item['qty'], $item['product_id']);
                    $stockStmt->execute();
                }
                
                $itemStmt->close();
                $stockStmt->close();

                // 3. AUTO SERVICE JOB GENERATION
                if ($print_total > 0 && $client_id > 0) {
                    $service_no = generate_no($conn, 'services', 'service_no', 'SRV');
                    
                    $combined_notes = "Auto-generated from Sale: $sale_no\n\nPrint Details:\n";
                    foreach ($items_to_save as $item) {
                        if ($item['print_charge'] > 0) {
                            $combined_notes .= "- Type: {$item['print_type']}, Notes: {$item['print_notes']}\n";
                        }
                    }
                    
                    $srvStmt = $conn->prepare("INSERT INTO services 
                        (service_no, client_id, sale_id, service_type, qty, print_charge_per_pc, total_amount, notes, status, service_date) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?)");
                    
                    $srv_qty = 1; 
                    $srv_rate = $print_total;
                    $srv_type = 'custom_print'; 
                    
                    $srvStmt->bind_param('siisiddss', $service_no, $client_id, $sale_id, $srv_type, $srv_qty, $srv_rate, $print_total, $combined_notes, $sale_date);
                    $srvStmt->execute();
                    $service_job_id = $srvStmt->insert_id;
                    $srvStmt->close();

                    // 4. Update Sale with Service Job ID
                    $updSale = $conn->prepare("UPDATE sales SET service_job_id = ? WHERE id = ?");
                    $updSale->bind_param('ii', $service_job_id, $sale_id);
                    $updSale->execute();
                    $updSale->close();
                }

                $conn->commit();
                set_flash('success', "Sale ($sale_no) created! Amount Paid: ₹$paid_amount, Due: ₹$due_amount");
                redirect('sales_list.php');

            } catch (Exception $e) {
                $conn->rollback();
                $error = 'Error: ' . $e->getMessage();
            }
        }
    }
}

include '../includes/header.php';
?>

<style>
    /* Fix for dark mode dropdowns */
    select {
        background-color: #1e293b !important;
        color: #fff !important;
    }
    select option {
        background-color: #1e293b !important;
        color: #fff !important;
        padding: 8px;
    }
</style>

<div class="flex items-center justify-between gap-3 mb-5">
    <div>
        <h1 class="text-2xl font-bold text-white">New Sale</h1>
        <p class="text-xs text-slate-400 mt-0.5">Customer ko maal bechen (Print, GST & Payment)</p>
    </div>
    <a href="sales_list.php" class="px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-slate-300 text-xs hover:bg-white/10 transition">
        <i class="fas fa-arrow-left mr-1"></i> Back
    </a>
</div>

<?php if ($error): ?>
    <div class="mb-4 rounded-xl p-3 text-sm bg-rose-500/15 border border-rose-500/30 text-rose-300">
        <i class="fas fa-exclamation-circle mr-2"></i><?= e($error) ?>
    </div>
<?php endif; ?>

<form method="POST" class="glass-dark rounded-2xl p-5 max-w-5xl" id="saleForm">
    <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6 pb-6 border-b border-white/10">
        <div>
            <label class="text-xs text-slate-400 mb-1 block">Client</label>
            <select name="client_id" class="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-slate-200 outline-none focus:border-indigo-500/50">
                <option value="0">-- Walk-in Customer --</option>
                <?php foreach ($clients as $c): ?>
                    <option value="<?= $c['id'] ?>"><?= e($c['client_name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div>
            <label class="text-xs text-slate-400 mb-1 block">Sale Date *</label>
            <input type="date" name="sale_date" required value="<?= date('Y-m-d') ?>" class="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-slate-200 outline-none focus:border-indigo-500/50">
        </div>
        <div>
            <label class="text-xs text-slate-400 mb-1 block">Payment Mode</label>
            <select name="payment_mode" class="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-slate-200 outline-none focus:border-indigo-500/50">
                <option value="cash">Cash</option>
                <option value="upi">UPI</option>
                <option value="bank">Bank Transfer</option>
                <option value="card">Card</option>
            </select>
        </div>
        <div>
            <label class="text-xs text-slate-400 mb-1 block">GST %</label>
            <select name="gst_percent" id="gstPercent" class="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-slate-200 outline-none focus:border-indigo-500/50" onchange="calculateGrandTotal()">
                <option value="0">0% (No GST)</option>
                <option value="5">5% GST</option>
                <option value="12">12% GST</option>
                <option value="18" selected>18% GST</option>
                <option value="28">28% GST</option>
            </select>
        </div>
    </div>

    <div class="mb-4">
        <div class="flex justify-between items-center mb-3">
            <h3 class="text-sm font-semibold text-white">Products</h3>
            <button type="button" onclick="addRow()" class="px-3 py-1.5 rounded-lg bg-indigo-500/20 text-indigo-300 text-xs font-semibold hover:bg-indigo-500/30 transition">
                <i class="fas fa-plus mr-1"></i> Add Product Row
            </button>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-xs" id="itemsTable">
                <thead>
                    <tr class="text-left border-b border-white/10">
                        <th class="pb-2 text-slate-400 font-medium w-1/4">Product</th>
                        <th class="pb-2 text-slate-400 font-medium text-center w-12">Qty</th>
                        <th class="pb-2 text-slate-400 font-medium text-right w-20">Rate (₹)</th>
                        <th class="pb-2 text-slate-400 font-medium text-right w-20">Print (₹)</th>
                        <th class="pb-2 text-slate-400 font-medium text-right w-20">Amount</th>
                        <th class="pb-2 text-slate-400 font-medium text-center w-8"></th>
                    </tr>
                </thead>
                <tbody id="itemsBody"></tbody>
            </table>
        </div>
    </div>

    <div class="flex flex-col md:flex-row justify-between items-start md:items-end gap-4 mb-6">
        <!-- Payment Section -->
        <div class="bg-white/5 rounded-lg p-4 border border-white/10 w-full md:w-1/2">
            <h3 class="text-sm font-semibold text-white mb-3">Payment Details</h3>
            <div class="flex gap-4">
                <div class="flex-1">
                    <label class="text-xs text-slate-400 mb-1 block">Paid Amount (₹) *</label>
                    <input type="number" step="1" min="0" name="paid_amount" id="paidAmount" required value="0" oninput="calculateDue()" class="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-emerald-300 outline-none focus:border-indigo-500/50">
                </div>
                <div class="flex-1">
                    <label class="text-xs text-slate-400 mb-1 block">Due Amount (₹)</label>
                    <input type="text" id="dueAmountDisplay" readonly value="0" class="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-rose-300 outline-none cursor-not-allowed">
                </div>
            </div>
            <p class="text-[10px] text-slate-500 mt-2">Agar pura paisa de raha hai, toh Paid Amount me Grand Total daal de.</p>
        </div>

        <!-- Totals Section -->
        <div class="bg-white/5 rounded-lg p-4 px-6 border border-white/10 text-right min-w-[250px] w-full md:w-auto">
            <div class="text-xs text-slate-400 flex justify-between mb-1"><span>Product Total:</span> <span id="prodTotalDisplay" class="text-white">₹0</span></div>
            <div class="text-xs text-slate-400 flex justify-between mb-1"><span>Print Total:</span> <span id="printTotalDisplay" class="text-amber-300">₹0</span></div>
            <div class="text-xs text-slate-400 flex justify-between mb-1 border-t border-white/5 pt-1"><span>Sub Total:</span> <span id="subTotalDisplay" class="text-white">₹0</span></div>
            <div class="text-xs text-slate-400 flex justify-between mb-2"><span>GST Amount:</span> <span id="gstDisplay" class="text-indigo-300">₹0</span></div>
            <div class="text-sm text-slate-300 font-semibold flex justify-between border-t border-white/10 pt-2"><span>Grand Total:</span> <span id="grandTotalDisplay" class="text-emerald-400 text-lg">₹0</span></div>
        </div>
    </div>

    <div class="flex items-center gap-2 pt-4 border-t border-white/5">
        <button type="submit" class="px-6 py-2.5 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-500 text-white text-sm font-semibold hover:-translate-y-0.5 hover:shadow-lg hover:shadow-indigo-500/30 transition-all">
            <i class="fas fa-save mr-1"></i> Save Sale
        </button>
        <a href="sales_list.php" class="px-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-slate-300 text-sm hover:bg-white/10 transition">Cancel</a>
    </div>
</form>

<script>
const productsList = <?= json_encode($products) ?>;

function addRow() {
    const tbody = document.getElementById('itemsBody');
    const rowId = Date.now() + Math.random().toString(36).substr(2, 5);

    const row = document.createElement('tr');
    row.className = 'border-b border-white/5 hover:bg-white/3 transition';
    row.id = 'row_' + rowId;

    let optionsHtml = '<option value="">-- Select Product --</option>';
    productsList.forEach(p => {
        optionsHtml += `<option value="${p.id}" data-price="${p.sale_price}" data-print="${p.print_charge}" data-stock="${p.stock_qty}">${p.product_name} (Stock: ${p.stock_qty})</option>`;
    });

    row.innerHTML = `
        <td class="py-2 pr-2">
            <select name="product_id[]" required onchange="onProductChange(this)" class="w-full bg-white/5 border border-white/10 rounded-lg px-2 py-1.5 text-xs text-slate-200 outline-none focus:border-indigo-500/50">
                ${optionsHtml}
            </select>
        </td>
        <td class="py-2 px-1">
            <input type="number" name="qty[]" min="1" value="1" required oninput="calculateRow('${rowId}')" class="w-full bg-white/5 border border-white/10 rounded-lg px-2 py-1.5 text-xs text-center text-slate-200 outline-none focus:border-indigo-500/50">
        </td>
        <td class="py-2 px-1">
            <!-- Rate input updated to integer -->
            <input type="number" step="1" min="0" name="rate[]" required oninput="calculateRow('${rowId}')" class="w-full bg-white/5 border border-white/10 rounded-lg px-2 py-1.5 text-xs text-right text-slate-200 outline-none focus:border-indigo-500/50 row-rate">
        </td>
        <td class="py-2 px-1">
            <!-- Integer Print Charge Input -->
            <input type="number" step="1" min="0" name="print_charge[]" value="0" oninput="onPrintChargeChange('${rowId}')" class="w-full bg-white/5 border border-white/10 rounded-lg px-2 py-1.5 text-xs text-right text-amber-300 outline-none focus:border-indigo-500/50 row-print">
        </td>
        <td class="py-2 px-1 text-right text-emerald-300 font-semibold row-amount">₹0</td>
        <td class="py-2 pl-2 text-center">
            <button type="button" onclick="removeRow('${rowId}')" class="w-6 h-6 rounded bg-rose-500/15 text-rose-300 hover:bg-rose-500/30 transition">
                <i class="fas fa-times text-[10px]"></i>
            </button>
        </td>
        <!-- Hidden Print Details Row -->
        <td colspan="6" class="pb-4 hidden print-details-row">
            <div class="bg-white/5 rounded-lg p-3 border border-white/10 flex gap-3 mt-2">
                <div class="w-1/3">
                    <label class="text-[10px] text-slate-400 block mb-1">Print Type</label>
                    <select name="print_type[]" class="w-full bg-white/5 border border-white/10 rounded-md px-2 py-1 text-xs text-slate-200 outline-none">
                        <option value="Logo">Logo</option>
                        <option value="Text">Text / Name</option>
                        <option value="Full Print">Full Design</option>
                    </select>
                </div>
                <div class="flex-1">
                    <label class="text-[10px] text-slate-400 block mb-1">Print Instructions / Design Notes</label>
                    <input type="text" name="print_notes[]" placeholder="e.g. Front me company logo, back me website..." class="w-full bg-white/5 border border-white/10 rounded-md px-2 py-1 text-xs text-slate-200 outline-none">
                </div>
            </div>
        </td>
    `;
    tbody.appendChild(row);
}

function removeRow(rowId) {
    document.getElementById('row_' + rowId).remove();
    calculateGrandTotal();
}

function onProductChange(select) {
    const price = select.options[select.selectedIndex].getAttribute('data-price');
    const print = select.options[select.selectedIndex].getAttribute('data-print');
    const row = select.closest('tr');
    
    if (price) row.querySelector('.row-rate').value = Math.round(price);
    if (print) row.querySelector('.row-print').value = Math.round(print);
    
    onPrintChargeChange(row.id.replace('row_', ''));
}

function onPrintChargeChange(rowId) {
    const row = document.getElementById('row_' + rowId);
    const printCharge = parseInt(row.querySelector('input[name="print_charge[]"]').value) || 0;
    const detailsRow = row.querySelector('.print-details-row');
    
    if (printCharge > 0) {
        detailsRow.classList.remove('hidden');
    } else {
        detailsRow.classList.add('hidden');
    }
    
    calculateRow(rowId);
}

function calculateRow(rowId) {
    const row = document.getElementById('row_' + rowId);
    const qty = parseFloat(row.querySelector('input[name="qty[]"]').value) || 0;
    const rate = parseFloat(row.querySelector('input[name="rate[]"]').value) || 0;
    const amount = qty * rate;
    
    row.querySelector('.row-amount').textContent = '₹' + amount.toFixed(0);
    calculateGrandTotal();
}

function calculateGrandTotal() {
    let prodTotal = 0;
    let printTotal = 0;
    
    document.querySelectorAll('#itemsBody > tr').forEach(row => {
        if (row.classList.contains('print-details-row')) return;
        
        const qty = parseFloat(row.querySelector('input[name="qty[]"]').value) || 0;
        const rate = parseFloat(row.querySelector('input[name="rate[]"]').value) || 0;
        const print = parseFloat(row.querySelector('input[name="print_charge[]"]').value) || 0;
        
        prodTotal += (qty * rate);
        printTotal += print;
    });
    
    const subTotal = prodTotal + printTotal;
    const gstPercent = parseFloat(document.getElementById('gstPercent').value) || 0;
    const gstAmount = (subTotal * gstPercent) / 100;
    const grandTotal = subTotal + gstAmount;
    
    document.getElementById('prodTotalDisplay').textContent = '₹' + prodTotal.toFixed(0);
    document.getElementById('printTotalDisplay').textContent = '₹' + printTotal.toFixed(0);
    document.getElementById('subTotalDisplay').textContent = '₹' + subTotal.toFixed(0);
    document.getElementById('gstDisplay').textContent = '₹' + gstAmount.toFixed(0);
    document.getElementById('grandTotalDisplay').textContent = '₹' + grandTotal.toFixed(0);
    
    calculateDue();
}

function calculateDue() {
    const grandTotalStr = document.getElementById('grandTotalDisplay').textContent.replace('₹', '');
    const grandTotal = parseFloat(grandTotalStr) || 0;
    const paidAmount = parseFloat(document.getElementById('paidAmount').value) || 0;
    
    let due = grandTotal - paidAmount;
    if (due < 0) due = 0;
    
    document.getElementById('dueAmountDisplay').value = due.toFixed(0);
}

window.onload = function() {
    addRow();
};
</script>

<?php include '../includes/footer.php'; ?>