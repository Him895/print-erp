<?php
// ============================================================
// FILE: sales/edit_sale.php
// ============================================================
require_once '../config/config.php';
require_login();

$page_title = 'Edit Sale';
$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) redirect('sales_list.php');

// Fetch Main Sale
$stmt = $conn->prepare("SELECT * FROM sales WHERE id = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$sale = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$sale) { set_flash('error', 'Sale not found.'); redirect('sales_list.php'); }

// Fetch Existing Items
$stmt = $conn->prepare("SELECT * FROM sale_items WHERE sale_id = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$sale_items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Fetch Clients & Products
$clients = $conn->query("SELECT * FROM clients WHERE is_active = 1 ORDER BY client_name")->fetch_all(MYSQLI_ASSOC);
// Include existing products even if stock is 0, to show in dropdown
$products = $conn->query("SELECT * FROM products WHERE is_active = 1 ORDER BY product_name")->fetch_all(MYSQLI_ASSOC);

include '../includes/header.php';
?>

<style>
    select { background-color: #1e293b !important; color: #fff !important; }
    select option { background-color: #1e293b !important; color: #fff !important; padding: 8px; }
</style>

<div class="flex items-center justify-between gap-3 mb-5">
    <div>
        <h1 class="text-2xl font-bold text-white">Edit Sale</h1>
        <p class="text-xs text-slate-400 mt-0.5">Invoice #<?= e($sale['sale_no']) ?></p>
    </div>
    <a href="sales_list.php" class="px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-slate-300 text-xs hover:bg-white/10 transition">
        <i class="fas fa-arrow-left mr-1"></i> Back
    </a>
</div>

<?php if (isset($_SESSION['error'])): ?>
    <div class="mb-4 rounded-xl p-3 text-sm bg-rose-500/15 border border-rose-500/30 text-rose-300">
        <i class="fas fa-exclamation-circle mr-2"></i><?= $_SESSION['error']; unset($_SESSION['error']); ?>
    </div>
<?php endif; ?>

<form action="update_sale.php" method="POST" class="glass-dark rounded-2xl p-5 max-w-5xl" id="saleForm">
    <input type="hidden" name="sale_id" value="<?= $id ?>">
    
    <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6 pb-6 border-b border-white/10">
        <div>
            <label class="text-xs text-slate-400 mb-1 block">Client</label>
            <select name="client_id" class="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-slate-200 outline-none focus:border-indigo-500/50">
                <option value="0">-- Walk-in Customer --</option>
                <?php foreach ($clients as $c): ?>
                    <option value="<?= $c['id'] ?>" <?= $sale['client_id'] == $c['id'] ? 'selected' : '' ?>><?= e($c['client_name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div>
            <label class="text-xs text-slate-400 mb-1 block">Sale Date *</label>
            <input type="date" name="sale_date" required value="<?= e($sale['sale_date']) ?>" class="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-slate-200 outline-none focus:border-indigo-500/50">
        </div>
        <div>
            <label class="text-xs text-slate-400 mb-1 block">Payment Mode</label>
            <select name="payment_mode" class="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-slate-200 outline-none focus:border-indigo-500/50">
                <option value="cash" <?= $sale['payment_mode'] == 'cash' ? 'selected' : '' ?>>Cash</option>
                <option value="upi" <?= $sale['payment_mode'] == 'upi' ? 'selected' : '' ?>>UPI</option>
                <option value="bank" <?= $sale['payment_mode'] == 'bank' ? 'selected' : '' ?>>Bank Transfer</option>
                <option value="card" <?= $sale['payment_mode'] == 'card' ? 'selected' : '' ?>>Card</option>
            </select>
        </div>
        <div>
            <label class="text-xs text-slate-400 mb-1 block">GST %</label>
            <select name="gst_percent" id="gstPercent" class="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-slate-200 outline-none focus:border-indigo-500/50" onchange="calculateGrandTotal()">
                <option value="0" <?= $sale['gst_percent'] == 0 ? 'selected' : '' ?>>0% (No GST)</option>
                <option value="5" <?= $sale['gst_percent'] == 5 ? 'selected' : '' ?>>5% GST</option>
                <option value="12" <?= $sale['gst_percent'] == 12 ? 'selected' : '' ?>>12% GST</option>
                <option value="18" <?= $sale['gst_percent'] == 18 ? 'selected' : '' ?>>18% GST</option>
                <option value="28" <?= $sale['gst_percent'] == 28 ? 'selected' : '' ?>>28% GST</option>
            </select>
        </div>
    </div>

    <div class="mb-4">
        <div class="flex justify-between items-center mb-3">
            <h3 class="text-sm font-semibold text-white">Products</h3>
            <button type="button" onclick="addRow()" class="px-3 py-1.5 rounded-lg bg-indigo-500/20 text-indigo-300 text-xs font-semibold hover:bg-indigo-500/30 transition">
                <i class="fas fa-plus mr-1"></i> Add Product Row
            </button>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-xs" id="itemsTable">
                <thead>
                    <tr class="text-left border-b border-white/10">
                        <th class="pb-2 text-slate-400 font-medium w-1/4">Product</th>
                        <th class="pb-2 text-slate-400 font-medium text-center w-12">Qty</th>
                        <th class="pb-2 text-slate-400 font-medium text-right w-20">Rate (₹)</th>
                        <th class="pb-2 text-slate-400 font-medium text-right w-20">Print (₹)</th>
                        <th class="pb-2 text-slate-400 font-medium text-right w-20">Amount</th>
                        <th class="pb-2 text-slate-400 font-medium text-center w-8"></th>
                    </tr>
                </thead>
                <tbody id="itemsBody">
                    <!-- Existing Items injected via JS -->
                </tbody>
            </table>
        </div>
    </div>

    <div class="flex flex-col md:flex-row justify-between items-start md:items-end gap-4 mb-6">
        <div class="bg-white/5 rounded-lg p-4 border border-white/10 w-full md:w-1/2">
            <h3 class="text-sm font-semibold text-white mb-3">Payment Details</h3>
            <div class="flex gap-4">
                <div class="flex-1">
                    <label class="text-xs text-slate-400 mb-1 block">Paid Amount (₹) *</label>
                    <input type="number" step="1" min="0" name="paid_amount" id="paidAmount" required value="<?= (int)$sale['paid_amount'] ?>" oninput="calculateDue()" class="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-emerald-300 outline-none focus:border-indigo-500/50">
                </div>
                <div class="flex-1">
                    <label class="text-xs text-slate-400 mb-1 block">Due Amount (₹)</label>
                    <input type="text" id="dueAmountDisplay" readonly value="<?= (int)$sale['due_amount'] ?>" class="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-rose-300 outline-none cursor-not-allowed">
                </div>
            </div>
        </div>

        <div class="bg-white/5 rounded-lg p-4 px-6 border border-white/10 text-right min-w-[250px] w-full md:w-auto">
            <div class="text-xs text-slate-400 flex justify-between mb-1"><span>Product Total:</span> <span id="prodTotalDisplay" class="text-white">₹0</span></div>
            <div class="text-xs text-slate-400 flex justify-between mb-1"><span>Print Total:</span> <span id="printTotalDisplay" class="text-amber-300">₹0</span></div>
            <div class="text-xs text-slate-400 flex justify-between mb-1 border-t border-white/5 pt-1"><span>Sub Total:</span> <span id="subTotalDisplay" class="text-white">₹0</span></div>
            <div class="text-xs text-slate-400 flex justify-between mb-2"><span>GST Amount:</span> <span id="gstDisplay" class="text-indigo-300">₹0</span></div>
            <div class="text-sm text-slate-300 font-semibold flex justify-between border-t border-white/10 pt-2"><span>Grand Total:</span> <span id="grandTotalDisplay" class="text-emerald-400 text-lg">₹0</span></div>
        </div>
    </div>

    <div class="flex items-center gap-2 pt-4 border-t border-white/5">
        <button type="submit" class="px-6 py-2.5 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-500 text-white text-sm font-semibold hover:-translate-y-0.5 hover:shadow-lg hover:shadow-indigo-500/30 transition-all">
            <i class="fas fa-save mr-1"></i> Update Sale
        </button>
        <a href="sales_list.php" class="px-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-slate-300 text-sm hover:bg-white/10 transition">Cancel</a>
    </div>
</form>

<script>
const productsList = <?= json_encode($products) ?>;
const existingItems = <?= json_encode($sale_items) ?>;

function addRow(selectedProductId = '', qty = 1, rate = 0, printCharge = 0, printType = 'Logo', printNotes = '') {
    const tbody = document.getElementById('itemsBody');
    const rowId = Date.now() + Math.random().toString(36).substr(2, 5);

    const row = document.createElement('tr');
    row.className = 'border-b border-white/5 hover:bg-white/3 transition';
    row.id = 'row_' + rowId;

    let optionsHtml = '<option value="">-- Select Product --</option>';
    productsList.forEach(p => {
        const selected = (p.id == selectedProductId) ? 'selected' : '';
        optionsHtml += `<option value="${p.id}" data-price="${p.sale_price}" data-print="${p.print_charge}" data-stock="${p.stock_qty}" ${selected}>${p.product_name} (Stock: ${p.stock_qty})</option>`;
    });

    row.innerHTML = `
        <td class="py-2 pr-2">
            <select name="product_id[]" required onchange="onProductChange(this)" class="w-full bg-white/5 border border-white/10 rounded-lg px-2 py-1.5 text-xs text-slate-200 outline-none focus:border-indigo-500/50">
                ${optionsHtml}
            </select>
        </td>
        <td class="py-2 px-1">
            <input type="number" name="qty[]" min="1" value="${qty}" required oninput="calculateRow('${rowId}')" class="w-full bg-white/5 border border-white/10 rounded-lg px-2 py-1.5 text-xs text-center text-slate-200 outline-none focus:border-indigo-500/50">
        </td>
        <td class="py-2 px-1">
            <input type="number" step="1" min="0" name="rate[]" required value="${rate}" oninput="calculateRow('${rowId}')" class="w-full bg-white/5 border border-white/10 rounded-lg px-2 py-1.5 text-xs text-right text-slate-200 outline-none focus:border-indigo-500/50 row-rate">
        </td>
        <td class="py-2 px-1">
            <input type="number" step="1" min="0" name="print_charge[]" value="${printCharge}" oninput="onPrintChargeChange('${rowId}')" class="w-full bg-white/5 border border-white/10 rounded-lg px-2 py-1.5 text-xs text-right text-amber-300 outline-none focus:border-indigo-500/50 row-print">
        </td>
        <td class="py-2 px-1 text-right text-emerald-300 font-semibold row-amount">₹0</td>
        <td class="py-2 pl-2 text-center">
            <button type="button" onclick="removeRow('${rowId}')" class="w-6 h-6 rounded bg-rose-500/15 text-rose-300 hover:bg-rose-500/30 transition">
                <i class="fas fa-times text-[10px]"></i>
            </button>
        </td>
        <!-- Hidden Print Details Row -->
        <td colspan="6" class="pb-4 hidden print-details-row">
            <div class="bg-white/5 rounded-lg p-3 border border-white/10 flex gap-3 mt-2">
                <div class="w-1/3">
                    <label class="text-[10px] text-slate-400 block mb-1">Print Type</label>
                    <select name="print_type[]" class="w-full bg-white/5 border border-white/10 rounded-md px-2 py-1 text-xs text-slate-200 outline-none">
                        <option value="Logo" ${printType == 'Logo' ? 'selected' : ''}>Logo</option>
                        <option value="Text" ${printType == 'Text' ? 'selected' : ''}>Text / Name</option>
                        <option value="Full Print" ${printType == 'Full Print' ? 'selected' : ''}>Full Design</option>
                    </select>
                </div>
                <div class="flex-1">
                    <label class="text-[10px] text-slate-400 block mb-1">Print Instructions / Design Notes</label>
                    <input type="text" name="print_notes[]" value="${printNotes}" placeholder="e.g. Front me company logo..." class="w-full bg-white/5 border border-white/10 rounded-md px-2 py-1 text-xs text-slate-200 outline-none">
                </div>
            </div>
        </td>
    `;
    tbody.appendChild(row);
    
    // Check print detail visibility
    const printInput = row.querySelector('.row-print');
    const detailsRow = row.querySelector('.print-details-row');
    if (parseInt(printInput.value) > 0) {
        detailsRow.classList.remove('hidden');
    }

    calculateRow(rowId);
}

function removeRow(rowId) {
    document.getElementById('row_' + rowId).remove();
    calculateGrandTotal();
}

function onProductChange(select) {
    const price = select.options[select.selectedIndex].getAttribute('data-price');
    const print = select.options[select.selectedIndex].getAttribute('data-print');
    const row = select.closest('tr');
    
    if (price) row.querySelector('.row-rate').value = Math.round(price);
    if (print) row.querySelector('.row-print').value = Math.round(print);
    
    onPrintChargeChange(row.id.replace('row_', ''));
}

function onPrintChargeChange(rowId) {
    const row = document.getElementById('row_' + rowId);
    const printCharge = parseInt(row.querySelector('input[name="print_charge[]"]').value) || 0;
    const detailsRow = row.querySelector('.print-details-row');
    
    if (printCharge > 0) {
        detailsRow.classList.remove('hidden');
    } else {
        detailsRow.classList.add('hidden');
    }
    
    calculateRow(rowId);
}

function calculateRow(rowId) {
    const row = document.getElementById('row_' + rowId);
    const qty = parseFloat(row.querySelector('input[name="qty[]"]').value) || 0;
    const rate = parseFloat(row.querySelector('input[name="rate[]"]').value) || 0;
    const amount = qty * rate;
    
    row.querySelector('.row-amount').textContent = '₹' + amount.toFixed(0);
    calculateGrandTotal();
}

function calculateGrandTotal() {
    let prodTotal = 0;
    let printTotal = 0;
    
    document.querySelectorAll('#itemsBody > tr').forEach(row => {
        if (row.classList.contains('print-details-row')) return;
        
        const qty = parseFloat(row.querySelector('input[name="qty[]"]').value) || 0;
        const rate = parseFloat(row.querySelector('input[name="rate[]"]').value) || 0;
        const print = parseFloat(row.querySelector('input[name="print_charge[]"]').value) || 0;
        
        prodTotal += (qty * rate);
        printTotal += print;
    });
    
    const subTotal = prodTotal + printTotal;
    const gstPercent = parseFloat(document.getElementById('gstPercent').value) || 0;
    const gstAmount = (subTotal * gstPercent) / 100;
    const grandTotal = subTotal + gstAmount;
    
    document.getElementById('prodTotalDisplay').textContent = '₹' + prodTotal.toFixed(0);
    document.getElementById('printTotalDisplay').textContent = '₹' + printTotal.toFixed(0);
    document.getElementById('subTotalDisplay').textContent = '₹' + subTotal.toFixed(0);
    document.getElementById('gstDisplay').textContent = '₹' + gstAmount.toFixed(0);
    document.getElementById('grandTotalDisplay').textContent = '₹' + grandTotal.toFixed(0);
    
    calculateDue();
}

function calculateDue() {
    const grandTotalStr = document.getElementById('grandTotalDisplay').textContent.replace('₹', '');
    const grandTotal = parseFloat(grandTotalStr) || 0;
    const paidAmount = parseFloat(document.getElementById('paidAmount').value) || 0;
    
    let due = grandTotal - paidAmount;
    if (due < 0) due = 0;
    
    document.getElementById('dueAmountDisplay').value = due.toFixed(0);
}

window.onload = function() {
    if (existingItems.length > 0) {
        existingItems.forEach(item => {
            addRow(item.product_id, item.qty, item.rate, item.print_charge_total, item.print_type, item.print_notes);
        });
    } else {
        addRow();
    }
};
</script>

<?php include '../includes/footer.php'; ?>