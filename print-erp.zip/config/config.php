<?php
// ============================================================
// FILE: config/config.php
// DESCRIPTION: Database connection + session + helpers
// ============================================================

// ---------- ERROR REPORTING (development) ----------
error_reporting(E_ALL);
ini_set('display_errors', 1);

// ---------- TIMEZONE ----------
date_default_timezone_set('Asia/Kolkata');

// ---------- DATABASE CREDENTIALS ----------
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');           // XAMPP default: empty
define('DB_NAME', 'print_erp');

// ---------- SITE CONSTANTS ----------
define('SITE_NAME', 'PrintERP');
define('SITE_VERSION', 'v1.0');
define('BASE_URL', 'http://localhost/print-erp/');
define('UPLOAD_DIR', __DIR__ . '/../assets/uploads/designs/');
define('UPLOAD_URL', BASE_URL . 'assets/uploads/designs/');

// ---------- DATABASE CONNECTION ----------
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");

// ---------- START SESSION (agar nahi chalu hai) ----------
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ============================================================
// HELPER FUNCTIONS
// ============================================================

/**
 * HTML escape (XSS se bachne ke liye)
 */
function e($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

/**
 * Redirect
 */
function redirect($url) {
    header("Location: $url");
    exit();
}

/**
 * Login check — agar login nahi hai to login.php pe bhejo
 */
function require_login() {
    if (!isset($_SESSION['user_id'])) {
        redirect(BASE_URL . 'login.php');
    }
}

/**
 * Role check — agar role match nahi to dashboard pe bhejo
 */
function require_role($roles = []) {
    require_login();
    if (!in_array($_SESSION['role'] ?? '', $roles)) {
        redirect(BASE_URL . 'dashboard.php');
    }
}

/**
 * Flash message set
 */
function set_flash($type, $msg) {
    $_SESSION['flash'] = ['type' => $type, 'msg' => $msg];
}

/**
 * Flash message get (aur delete)
 */
function get_flash() {
    if (isset($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $f;
    }
    return null;
}

/**
 * Auto-generate next number (e.g. SALE-2025-0001)
 */
function generate_no($conn, $table, $column, $prefix) {
    $year = date('Y');
    $like = $prefix . '-' . $year . '-%';
    $stmt = $conn->prepare("SELECT $column FROM $table WHERE $column LIKE ? ORDER BY id DESC LIMIT 1");
    $stmt->bind_param('s', $like);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($row = $res->fetch_assoc()) {
        $last = (int) substr($row[$column], strrpos($row[$column], '-') + 1);
        $next = $last + 1;
    } else {
        $next = 1;
    }
    $stmt->close();
    return $prefix . '-' . $year . '-' . str_pad($next, 4, '0', STR_PAD_LEFT);
}

/**
 * File upload (design file)
 * Return: file path (relative) ya false
 */
function upload_design($file) {
    if (empty($file['name'])) return null;
    if ($file['error'] !== UPLOAD_ERR_OK) return false;
    if ($file['size'] > 5 * 1024 * 1024) return false; // 5MB max

    $allowed = ['jpg','jpeg','png','pdf','svg','ai','cdr'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed)) return false;

    if (!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR, 0777, true);

    $newName = 'design_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    if (move_uploaded_file($file['tmp_name'], UPLOAD_DIR . $newName)) {
        return $newName;
    }
    return false;
}

/**
 * Currency format
 */
function money($n) {
    return '₹' . number_format((float)$n, 2);
}

/**
 * Date format (dd M Y)
 */
function fmt_date($d) {
    if (!$d) return '-';
    return date('d M Y', strtotime($d));
}

// ---------- DONE ----------
?>